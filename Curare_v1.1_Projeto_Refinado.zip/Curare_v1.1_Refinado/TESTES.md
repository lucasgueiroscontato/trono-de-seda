# Curare — Fases 1–3 / refinamento 1.1: roteiro de verificação

## Executado neste ambiente

- [x] Leitura do projeto anterior (`Curare_Fase2`) e preservação das telas de Fases 1 e 2.
- [x] Integração de telas de busca, filtro, detalhes, agendamento, pedidos, chat e ocorrências.
- [x] Kotlin/JVM: script `checks/verificar-kotlin.sh` executado com sucesso (36 verificações `check` com contagem dinâmica).
- [x] Novas validações: agenda efetivamente livre, limite de 14 dias, impossibilidade de contratar o próprio perfil, cancelamento liberando horários.
- [x] Checagem estática (`checks/verificar-projeto.py`): estrutura, XML, manifesto, permissões e versões.
- [x] Regras testadas: busca sem acentos, categorias, ordem, correspondência de dia da semana, passado/futuro, conflitos de horários, cancelamento local, filtragem de disponibilidade, respostas da CuraAI e anúncio próprio local.
- [x] Casos JUnit adicionados em `app/src/test/java` para catálogo, agenda, busca, mensagens e dados existentes.
- [x] Inspeção da configuração Gradle e fluxo de build via GitHub Actions.
- [ ] Testes JUnit **não executados via Gradle** neste ambiente.
- [ ] Compilação Android / geração de APK **não executada**: Android SDK e Gradle não estão presentes; não há arquivo `.apk` no projeto.
- [ ] Testes instrumentados, emulador e aparelho Android **não executados**.

## Checklist manual após gerar APK

1. Abrir em celular Android pequeno e grande. Observar status bar, teclado, scroll, textos longos e barra inferior. Não deve haver sobreposição.
2. Criar perfil **Cliente**, fechar e reabrir. Confirmar persistência de nome e idade.
3. Abrir Serviços. Buscar `Gomes`, `animais`, `CUIDADOS`; experimentar filtros e ordenação e limpar filtros sem resultados.
4. Abrir Gomes, conferir biografia e horários; rolar a seleção horizontal de dias em uma tela estreita. Criar pedido local com horário livre.
5. Confirmar que um segundo pedido no mesmo horário fica bloqueado e que a busca com "Com horário livre" considera as reservas do aparelho. Em **Meus pedidos**, cancelar o primeiro com confirmação e repetir.
6. Pressionar **Outro horário? Conversar** na tela de agendamento. Digitar uma mensagem; simular resposta. Retornar e reabrir a mesma conversa. Confirmar persistência.
7. Fazer outro chat com Renata. Confirmar que os históricos de Gomes e Renata não se misturam.
8. Abrir Ajuda e conversar com CuraAI sobre `agenda`, `denúncia`, `pagamento` e `emergência`. Verificar respostas apropriadas e indicação de atendimento simulado.
9. Em Reclamações e denúncias, registrar um exemplo com mais de dez caracteres; voltar e verificar a lista salva. Confirmar ausência de envio remoto.
10. Trocar para **Prestador(a)**; editar bio e serviços, adicionar agenda semanal. Na busca, desativar `Com agenda` se necessário e localizar o próprio anúncio, indicado como local.
11. Abrir histórico da Fase 2; carregar exemplos e verificar avaliações, detalhes e ocorrência vinculada ao serviço.
12. Confirmar que o botão Gov.br continua desativado e que o aplicativo não pede permissões de rede, localização ou câmera.
13. Com teclado aberto, voltar entre detalhes, perfil, chat e agenda sem crashes. Reiniciar app e confirmar persistência.
14. Verificar acessibilidade: leitor de tela, toque nas estrelas, contraste e fonte ampliada. Refinamentos adicionais dependem dos testes reais.

## Conhecidas limitações do protótipo

- A agenda mostra **janelas semanais** de exemplo, não disponibilidade em tempo real.
- Solicitar/cancelar pedidos afeta apenas o armazenamento local e não envia notificações.
- Chats não são conexões entre usuários; a resposta do prestador deve ser ativada pelo botão de simulação.
- CuraAI é um sistema simples de regras, sem modelo de linguagem nem análise real de denúncias.
- Os dados de demonstração em `SharedPreferences` não foram projetados para armazenar informações sensíveis.

15. Em aparelho recém-instalado, abrir um prestador e clicar em Agendar; criar perfil; confirmar retorno ao agendamento. Repetir para Conversar.
16. Alterar o tamanho de fonte e navegar nas telas de agendamento e chat, conferindo contrastes e componentes tocáveis.
