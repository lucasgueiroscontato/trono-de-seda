# Curare — Três fases integradas | versão 1.1.0-academico (refinada)

Aplicativo Android **nativo**, em **Kotlin + Jetpack Compose**. Esta pasta é o projeto completo e incremental: **Fases 1, 2 e 3 no mesmo aplicativo, com revisão adicional da versão 1.1**. Criado como **protótipo acadêmico offline** com base nos mockups: folhas verdes, azul-água claro, cards brancos, menu, perfil com estrelas e mascote de gatinho.

> **Importante:** os perfis do catálogo são fictícios, a CuraAI é uma simulação determinística, e **nenhuma** mensagem, solicitação, avaliação ou denúncia é enviada a outras pessoas. Não há contratação, autenticação, verificação Gov.br, pagamentos, banco de dados remoto, nem suporte humano real. Não use para situações reais ou dados pessoais sensíveis.

## Telas e ações

### Fase 1 (mantida)

- Tela de boas-vindas com logotipo Curare, folhas, menu e paleta pastel;
- Cadastro com seleção **Cliente** / **Prestador(a)**, nome e idade opcional;
- Persistência local do cadastro; edição do cadastro;
- Botão **Gov.br** visível mas desativado, identificado como ilustrativo;
- Navegação: Perfil, Serviços e Ajuda.

### Fase 2 (mantida e refinada)

- Perfil com avatar ilustrativo, biografia e serviços editáveis;
- Avaliações de 1 a 5 estrelas, média de registros locais;
- Agenda semanal com adição/remoção, sem horários inválidos, repetidos ou sobrepostos;
- Histórico de serviços, detalhes, avaliações e exemplos fictícios;
- Formulário de ocorrência associado ao registro fictício;
- Armazenamento local (`SharedPreferences`) preservado entre reinicializações;
- Melhoria do toque nas estrelas, cabeçalho e barras de navegação.

### Fase 3 (nova)

- **Busca:** lista de 6 prestadores fictícios com nome, avatar, descrição, categorias, avaliação e horários semanais;
- **Filtros:** texto sem distinção de maiúsculas e acentos, categorias, disponibilidade realmente livre nos próximos 14 dias (considerando pedidos locais) e ordenação por melhores avaliações ou maior número de faixas de horário;
- **Prestador cadastrado no aparelho:** aparece também como anúncio local, com seus serviços e horários do perfil, e indicação de que só existe naquele aparelho. Não é possível contratar a si mesmo;
- **Detalhes do prestador:** biografia, avaliação e agenda visível;
- **Solicitações:** escolha de uma data entre as próximas duas semanas, com dias roláveis para telas estreitas, faixa de horário da agenda, observações e confirmação explícita de **pedido local de demonstração**. Não permite data anterior, horário passado do dia corrente, fora da agenda ou ocupado por outro pedido local do mesmo prestador;
- **Meus pedidos:** histórico de solicitações locais, cancelamento local com confirmação e atalho para chat;
- **Chat entre cliente e prestador:** mensagens digitadas pelo usuário permanecem no dispositivo, separadas por prestador. Há uma ação opcional para **simular** a resposta do prestador e testar conversas em duas direções. Não existe comunicação remota;
- **CuraAI:** assistente local baseado em respostas programadas para agenda, reclamações, segurança e pagamentos. O rótulo informa que **não** é IA conectada nem atendimento humano;
- **Reclamações e denúncias de exemplo:** tela para escrever uma ocorrência **fictícia**, associar opcionalmente a um prestador e consultá-la localmente;
- **Persistência:** mensagens de exemplo, pedidos e ocorrências sobrevivem ao fechamento do aplicativo;
- **Navegação:** telas de detalhe têm seta de retorno; abas principais ficam acessíveis por menu e barra inferior; a ação de agendar ou conversar é retomada após o primeiro cadastro.
- **Refinamento visual:** legendas mais legíveis, menu de boas-vindas com melhor contraste, datas roláveis e proteção contra ações acidentais.

## Como compilar o APK (Android Studio)

1. Descompacte o ZIP; abra a pasta `Curare_Fase3` no Android Studio.
2. Use **JDK 17**, Android **SDK Platform 36**, Android SDK **Build Tools 35.0.0**, Gradle **8.13**, Android Gradle Plugin **8.13.2** e Kotlin **2.2.21**. Essas versões já estão declaradas nos arquivos Gradle.
3. Sincronize o projeto e execute **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Saída esperada: `app/build/outputs/apk/debug/app-debug.apk`.

**Observação sobre o wrapper:** inclui `gradle/wrapper/gradle-wrapper.properties`, mas não o `gradle-wrapper.jar` nem scripts `gradlew`. Caso o Android Studio não disponha de Gradle 8.13, configure um Gradle local na IDE, ou use GitHub Actions abaixo. **Não tente rodar `./gradlew` deste ZIP**, pois o wrapper está incompleto.

## Compilação no GitHub Actions — alternativa para celular

O projeto inclui `.github/workflows/gerar-apk.yml`, que instala JDK/SDK/Gradle, executa os testes JUnit e compila o `app-debug.apk`.

1. Crie um repositório GitHub e coloque **o conteúdo descompactado de `Curare_Fase3/`** na raiz do repositório, preservando a estrutura de pastas (inclusive a pasta oculta `.github`). **Enviar só o ZIP não dispara a compilação**.
2. Na aba **Actions**, abra o workflow **Gerar APK de demonstração** e escolha **Run workflow**. O push para `main` ou `master` também inicia o build.
3. Após o build **ter êxito**, abra o job e baixe o artifact `Curare-v1.1-APK-debug`. Descompacte-o para obter `app-debug.apk`.
4. Instale o APK em seu Android. Por ser um APK de debug, não é próprio para publicação.

A pipeline requer internet e acesso ao Android SDK no GitHub. A execução dela não foi feita no ambiente de criação.

## Como testar lógica local sem Android SDK

Se houver Kotlin CLI instalado:

```sh
bash checks/verificar-kotlin.sh
python3 checks/verificar-projeto.py
```

O primeiro script compila as regras Kotlin sem Android e executa **36 verificações** de busca, calendário, cadastro, conflito de reservas e regras da CuraAI. O segundo confirma a estrutura de arquivos e o XML. **Nenhum deles compila o Android ou valida a interface Compose.** O arquivo `TESTES.md` contém o roteiro de validação de interface e os resultados existentes.

## Estrutura

```text
Curare_Fase3/
├── .github/workflows/gerar-apk.yml
├── app/
│   ├── build.gradle.kts
│   └── src/
│       ├── main/java/br/com/curare/
│       │   ├── MainActivity.kt
│       │   ├── data/
│       │   │   ├── Profile.kt / ProfileValidation.kt
│       │   │   ├── CareModels.kt / LocalCareRepository.kt
│       │   │   ├── LocalProfileRepository.kt
│       │   │   ├── MarketplaceModels.kt
│       │   │   └── LocalMarketplaceRepository.kt
│       │   └── ui/
│       │       ├── CurareApp.kt
│       │       ├── components/
│       │       ├── theme/
│       │       └── screens/
│       │           ├── ProfileScreen.kt / AvailabilitySection.kt
│       │           ├── HistoryScreen.kt / IncidentReportScreen.kt
│       │           ├── MarketplaceScreens.kt
│       │           └── ChatScreens.kt
│       └── test/java/br/com/curare/data/MarketplaceModelsTest.kt
├── checks/VerifyPhase3.kt
├── checks/verificar-kotlin.sh
├── TESTES.md
└── README.md
```

## Limitações para evolução a produto real

Necessários antes de uso verdadeiro: backend com contas e identidades verificadas, autorização e autorização por recurso, segurança dos dados, moderação e suporte humano, fluxo de denúncia real, agenda transacional por usuário, notificações, consentimento e privacidade adequados, termos de uso, acessibilidade testada, auditoria de avaliações, pagamentos seguros e testes completos em dispositivos. O protótipo **não** deve ser apresentado como serviço ativo.

## Validação da edição 1.1 neste ambiente

- **PASSOU:** 36 verificações Kotlin/JVM, sem Android SDK.
- **PASSOU:** verificação de arquivos essenciais, XML e declaração de permissões.
- **NÃO EXECUTADO:** testes JUnit via Gradle, build `:app:assembleDebug`, instalação em aparelho, inspeção visual em emulador e validação da acessibilidade no sistema Android.
- **IMPEDIMENTO:** ambiente de edição sem Gradle, Android SDK, Android Emulator e acesso de rede para instalar essas dependências.

Veja `RELATORIO_VALIDACAO.md` para o registro detalhado. O projeto contém a configuração de compilação; **não contém APK pronto**, pois não foi possível executá-la aqui.
