package br.com.curare.data

import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class MarketplaceModelsTest {
    private val providers = sampleProviders()
    private fun date(y: Int, m: Int, d: Int, h: Int = 9): Calendar =
        Calendar.getInstance().apply { set(y, m - 1, d, h, 0, 0); set(Calendar.MILLISECOND, 0) }

    @Test fun `catálogo possui categorias e nomes únicos`() {
        assertEquals(6, providers.size)
        assertEquals(6, providers.map { it.id }.distinct().size)
        assertTrue(providers.all { it.categories.isNotEmpty() && it.rating in 1.0..5.0 })
    }

    @Test fun `busca funciona com acentos e filtros`() {
        assertTrue(searchProviders(providers, "não existente", null, false).isEmpty())
        assertTrue(searchProviders(providers, "animais", CareCategory.ANIMAIS, true).all { CareCategory.ANIMAIS in it.categories })
        assertEquals("gomes", searchProviders(providers, "acompanhamento", null, false).first().id)
    }

    @Test fun `ordenação mostra mais bem avaliados antes`() {
        val result = searchProviders(providers, "", null, true)
        assertEquals("gomes", result.first().id)
        assertEquals("raquel", result.last().id)
        assertEquals(result.map { it.rating }.sortedDescending(), result.map { it.rating })
    }

    @Test fun `dia da semana confere com calendario`() {
        assertEquals(WeekDay.THURSDAY, dayForDate("29/10/2026"))
        assertEquals(WeekDay.MONDAY, dayForDate("02/11/2026"))
        assertNull(dayForDate("31/02/2026"))
    }

    @Test fun `solicitação requer data futura e agenda correspondente`() {
        val gomes = providers.first { it.id == "gomes" }
        val now = date(2026, 10, 29)
        assertTrue(canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", emptyList(), now))
        assertFalse(canRequestBooking(gomes, "28/10/2026", "12:00", "16:00", emptyList(), now))
        assertFalse(canRequestBooking(gomes, "31/10/2026", "12:00", "16:00", emptyList(), now))
        assertFalse(canRequestBooking(gomes, "02/11/2026", "11:00", "16:00", emptyList(), now))
        assertFalse(canRequestBooking(gomes, "02/11/2026", "12:00", "17:00", emptyList(), now))
    }

    @Test fun `não permite agendamento no passado do mesmo dia`() {
        val raquel = providers.first { it.id == "raquel" }
        assertFalse(canRequestBooking(raquel, "04/11/2026", "15:00", "19:00",
            emptyList(), date(2026, 11, 4, 17)))
        assertTrue(canRequestBooking(raquel, "04/11/2026", "15:00", "19:00",
            emptyList(), date(2026, 11, 4, 10)))
    }

    @Test fun `detecta reservas em conflito e cancela corretamente`() {
        val gomes = providers.first { it.id == "gomes" }
        val now = date(2026, 10, 29)
        val booking = DemoBooking("1", gomes.id, CareCategory.IDOSOS, "02/11/2026", "12:00", "16:00", "", 0)
        assertFalse(canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", listOf(booking), now))
        assertTrue(canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", listOf(booking.copy(cancelled = true)), now))
    }

    @Test fun `próximas datas incluem apenas dias de agenda`() {
        val gomes = providers.first { it.id == "gomes" }
        val dates = upcomingProviderDates(gomes, date(2026, 10, 29))
        assertTrue("30/10/2026" in dates)
        assertTrue("02/11/2026" in dates)
        assertFalse("31/10/2026" in dates)
    }

    @Test fun `perfil local aparece com horários sem enviar dados ao catálogo remoto`() {
        val user = Profile("Maria Teste", 25, UserRole.PRESTADOR, "Cuidados com gatos", "Animais e pets")
        val provider = localProvider(user, listOf(AvailabilitySlot(WeekDay.MONDAY, "09:00", "11:00")), emptyList())
        assertTrue(provider.isOwnLocalProfile)
        assertEquals("Maria Teste", provider.name)
        assertTrue(CareCategory.ANIMAIS in provider.categories)
        assertEquals(0.0, provider.rating, 0.0001)
        assertEquals(1, provider.slots.size)
    }

    @Test fun `bloqueia agendamento fora do período de quatorze dias`() {
        val gomes = providers.first { it.id == "gomes" }
        assertFalse(canRequestBooking(gomes, "16/11/2026", "12:00", "16:00", emptyList(), date(2026, 10, 29)))
    }

    @Test fun `filtro de horario livre considera pedidos locais e cancelamentos`() {
        val gomes = providers.first { it.id == "gomes" }
        val now = date(2026, 10, 29)
        assertTrue(hasBookableSlot(gomes, emptyList(), now))
        val occupied = upcomingProviderDates(gomes, now).flatMap { day ->
            gomes.slots.filter { it.day == dayForDate(day) }.map { slot ->
                DemoBooking("$day-${slot.startsAt}", gomes.id, CareCategory.IDOSOS,
                    day, slot.startsAt, slot.endsAt, "", 0)
            }
        }
        assertFalse(hasBookableSlot(gomes, occupied, now))
        assertTrue(hasBookableSlot(gomes, occupied.map { it.copy(cancelled = true) }, now))
    }

    @Test fun `anuncio proprio nao aceita agendamento`() {
        val own = localProvider(Profile("Ana", 18, UserRole.PRESTADOR),
            listOf(AvailabilitySlot(WeekDay.MONDAY, "09:00", "11:00")), emptyList())
        assertFalse(canRequestBooking(own, "02/11/2026", "09:00", "11:00", emptyList(), date(2026, 10, 29)))
    }

    @Test fun `respostas automatizadas identificam temas essenciais`() {
        assertTrue(demoSupportReply("Quero denunciar uma conduta").contains("ocorrência fictícia"))
        assertTrue(demoSupportReply("Há uma emergência").contains("socorro"))
        assertTrue(demoSupportReply("Qual é o preço?").contains("pagamentos"))
        assertTrue(demoSupportReply("Quero agendar um horário").contains("aba Serviços"))
        assertEquals("provider:renata", threadFor("renata"))
    }
}
