package br.com.curare.data

import org.junit.Assert.*
import org.junit.Test

class ProfileValidationTest {
    @Test fun displayNameHasMinimumLength() {
        assertFalse(isValidDisplayName(" "))
        assertFalse(isValidDisplayName("A"))
        assertTrue(isValidDisplayName("Ana"))
        assertTrue(isValidDisplayName("  João Silva "))
    }

    @Test fun ageIsOptionalButValidated() {
        assertTrue(isValidAgeField(""))
        assertTrue(isValidAgeField("18"))
        assertFalse(isValidAgeField("0"))
        assertFalse(isValidAgeField("121"))
        assertFalse(isValidAgeField("abc"))
        assertEquals(18, parseOptionalAge("18"))
        assertNull(parseOptionalAge(""))
    }
}
