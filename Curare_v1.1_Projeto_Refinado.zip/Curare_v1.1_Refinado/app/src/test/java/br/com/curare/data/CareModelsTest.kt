package br.com.curare.data

import org.junit.Assert.*
import org.junit.Test

class CareModelsTest {
    @Test fun rejectsInvalidTimes() {
        assertTrue(validTime("00:00"))
        assertTrue(validTime("23:59"))
        assertFalse(validTime("24:00"))
        assertFalse(validTime("8:30"))
        assertFalse(validTime("13:60"))
    }

    @Test fun preventsOverlapsButAllowsAdjacentSlots() {
        val booked = listOf(AvailabilitySlot(WeekDay.MONDAY, "09:00", "12:00"))
        assertFalse(canAddSlot(AvailabilitySlot(WeekDay.MONDAY, "11:00", "14:00"), booked))
        assertFalse(canAddSlot(AvailabilitySlot(WeekDay.MONDAY, "09:00", "12:00"), booked))
        assertFalse(canAddSlot(AvailabilitySlot(WeekDay.MONDAY, "17:00", "16:00"), booked))
        assertTrue(canAddSlot(AvailabilitySlot(WeekDay.MONDAY, "12:00", "16:00"), booked))
        assertTrue(canAddSlot(AvailabilitySlot(WeekDay.TUESDAY, "11:00", "14:00"), booked))
    }

    @Test fun historyRatingsAreCalculated() {
        assertNull(averageRating(emptyList()))
        assertEquals(4.5, averageRating(listOf(
            ServiceRecord("1", "Ana", "Hospital", "01/09/2026", "09:00", "12:00", 4, ""),
            ServiceRecord("2", "Bia", "Clínica", "02/09/2026", "09:00", "12:00", 5, "")
        ))!!, 0.0001)
        assertEquals(3.75, averageRating(sampleHistory())!!, 0.0001)
    }

    @Test fun rejectsInvalidDatesAndAcceptsLeapYear() {
        assertTrue(validDate("29/02/2024"))
        assertFalse(validDate("29/02/2025"))
        assertFalse(validDate("31/04/2026"))
        assertFalse(validDate("01-01-2026"))
    }

    @Test fun sampleRecordsAreValidAndExplicitlyDemo() {
        assertTrue(sampleHistory().all(::validateRecord))
        assertTrue(sampleHistory().all { it.isDemo })
    }
}
