package br.com.curare.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.CatMark
import br.com.curare.ui.components.CurareWordmark
import br.com.curare.ui.screens.*
import br.com.curare.ui.theme.*
import java.util.UUID

/** Navegação simples da demonstração acadêmica — não há rede, pagamento ou usuários externos. */
private enum class Screen {
    WELCOME, REGISTER, PROFILE, HISTORY, HISTORY_DETAIL, REPORT,
    SERVICES, PROVIDER_DETAIL, BOOKING, MY_BOOKINGS,
    HELP, DIRECT_CHAT, SUPPORT_CHAT, SUPPORT_REPORT
}

@Composable
fun CurareApp(
    repository: LocalProfileRepository,
    care: LocalCareRepository,
    marketplace: LocalMarketplaceRepository
) {
    var profile by remember { mutableStateOf(repository.load()) }
    var records by remember { mutableStateOf(care.loadHistory()) }
    var availability by remember { mutableStateOf(care.loadAvailability()) }
    var reports by remember { mutableStateOf(care.loadReports()) }
    var bookings by remember { mutableStateOf(marketplace.loadBookings()) }
    var messages by remember { mutableStateOf(marketplace.loadMessages()) }
    val providers = remember(profile, availability, records) {
        sampleProviders() + listOfNotNull(profile?.takeIf { it.role == UserRole.PRESTADOR }
            ?.let { localProvider(it, availability, records) })
    }
    var selectedProviderId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedRecordId by rememberSaveable { mutableStateOf<String?>(null) }
    var screenName by rememberSaveable { mutableStateOf(Screen.WELCOME.name) }
    var chatReturnName by rememberSaveable { mutableStateOf(Screen.SERVICES.name) }
    // Preserva a ação solicitada (agendar ou conversar) após o primeiro cadastro.
    var pendingAfterRegister by rememberSaveable { mutableStateOf<String?>(null) }
    var reportReturnName by rememberSaveable { mutableStateOf(Screen.HELP.name) }
    val screen = Screen.entries.firstOrNull { it.name == screenName } ?: Screen.WELCOME
    var menuOpen by remember { mutableStateOf(false) }
    val navigate: (Screen) -> Unit = { target ->
        if (screen == Screen.REGISTER && target != Screen.REGISTER) pendingAfterRegister = null
        screenName = target.name
        menuOpen = false
    }
    val openChat: (String, Screen) -> Unit = { providerId, previous ->
        selectedProviderId = providerId
        chatReturnName = previous.name
        navigate(Screen.DIRECT_CHAT)
    }
    val back: () -> Unit = {
        if (screen == Screen.REGISTER) pendingAfterRegister = null
        navigate(when (screen) {
            Screen.REGISTER -> if (profile == null) Screen.WELCOME else Screen.PROFILE
            Screen.PROFILE -> Screen.WELCOME
            Screen.HISTORY -> Screen.PROFILE
            Screen.HISTORY_DETAIL -> Screen.HISTORY
            Screen.REPORT -> Screen.HISTORY_DETAIL
            Screen.SERVICES -> Screen.PROFILE
            Screen.PROVIDER_DETAIL -> Screen.SERVICES
            Screen.BOOKING -> Screen.PROVIDER_DETAIL
            Screen.MY_BOOKINGS -> Screen.SERVICES
            Screen.HELP -> Screen.PROFILE
            Screen.DIRECT_CHAT -> Screen.entries.firstOrNull { it.name == chatReturnName } ?: Screen.SERVICES
            Screen.SUPPORT_CHAT -> Screen.HELP
            Screen.SUPPORT_REPORT -> Screen.entries.firstOrNull { it.name == reportReturnName } ?: Screen.HELP
            Screen.WELCOME -> Screen.WELCOME
        })
    }
    BackHandler(enabled = screen != Screen.WELCOME || menuOpen) {
        if (menuOpen) menuOpen = false else back()
    }

    val selectedProvider = providers.firstOrNull { it.id == selectedProviderId }
    val selectedRecord = records.firstOrNull { it.id == selectedRecordId }
    val isMainTab = screen in setOf(Screen.PROFILE, Screen.SERVICES, Screen.HELP)
    Scaffold(
        containerColor = if (screen == Screen.WELCOME) Cloud else Color.White,
        topBar = {
            CurareHeader(
                isWelcome = screen == Screen.WELCOME,
                showBack = screen !in setOf(Screen.WELCOME, Screen.PROFILE, Screen.SERVICES, Screen.HELP),
                onBack = back,
                onMenuClick = { menuOpen = !menuOpen }, menuOpen = menuOpen,
                onMenuDismiss = { menuOpen = false }, navigate = navigate
            )
        },
        bottomBar = {
            if (isMainTab) NavigationBar(containerColor = Cloud, tonalElevation = 0.dp) {
                BottomTab("Perfil", "●", screen == Screen.PROFILE) { navigate(Screen.PROFILE) }
                BottomTab("Serviços", "⌕", screen == Screen.SERVICES) { navigate(Screen.SERVICES) }
                BottomTab("Ajuda", "✉", screen == Screen.HELP) { navigate(Screen.HELP) }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.WELCOME -> WelcomeScreen(profile,
                    onRegister = { navigate(Screen.REGISTER) }, onEnter = { navigate(Screen.PROFILE) })
                Screen.REGISTER -> RegistrationScreen(profile) { saved ->
                    repository.save(saved)
                    profile = saved
                    val next = Screen.entries.firstOrNull { it.name == pendingAfterRegister }
                        ?: Screen.PROFILE
                    pendingAfterRegister = null
                    navigate(next)
                }
                Screen.PROFILE -> ProfileScreen(profile, records, availability,
                    onRegister = { navigate(Screen.REGISTER) },
                    onUpdateBio = { bio, services ->
                        profile?.copy(bio = bio, offeredServices = services)?.let { updated ->
                            repository.save(updated); profile = updated
                        }
                    },
                    onUpdateAvailability = { slots ->
                        care.saveAvailability(slots); availability = slots
                    },
                    onHistory = { navigate(Screen.HISTORY) },
                    onCustomTime = { navigate(Screen.HELP) }
                )
                Screen.HISTORY -> HistoryScreen(records, reports,
                    onAddRecord = { item ->
                        val newRecords = listOf(item) + records
                        care.saveHistory(newRecords); records = newRecords
                    },
                    onLoadExamples = {
                        if (records.isEmpty()) {
                            val examples = sampleHistory()
                            care.saveHistory(examples); records = examples
                        }
                    },
                    onOpenDetail = { id -> selectedRecordId = id; navigate(Screen.HISTORY_DETAIL) }
                )
                Screen.HISTORY_DETAIL -> HistoryDetailScreen(selectedRecord,
                    reported = reports.any { it.serviceId == selectedRecordId },
                    onGoBack = { navigate(Screen.HISTORY) }, onReport = { navigate(Screen.REPORT) })
                Screen.REPORT -> IncidentReportScreen(selectedRecord, onSave = { report ->
                    if (reports.none { it.serviceId == report.serviceId }) {
                        val updated = reports + report
                        care.saveReports(updated); reports = updated
                    }
                    navigate(Screen.HISTORY_DETAIL)
                }, onBack = { navigate(Screen.HISTORY_DETAIL) })
                Screen.SERVICES -> ServicesScreen(providers, bookings,
                    onOpenProvider = { id -> selectedProviderId = id; navigate(Screen.PROVIDER_DETAIL) },
                    onMyBookings = { navigate(Screen.MY_BOOKINGS) })
                Screen.PROVIDER_DETAIL -> ProviderDetailsScreen(selectedProvider,
                    onBack = { navigate(Screen.SERVICES) },
                    onBook = {
                        if (profile == null) {
                            pendingAfterRegister = Screen.BOOKING.name
                            navigate(Screen.REGISTER)
                        } else navigate(Screen.BOOKING)
                    },
                    onChat = {
                        if (profile == null) {
                            chatReturnName = Screen.PROVIDER_DETAIL.name
                            pendingAfterRegister = Screen.DIRECT_CHAT.name
                            navigate(Screen.REGISTER)
                        } else selectedProviderId?.let { openChat(it, Screen.PROVIDER_DETAIL) }
                    })
                Screen.BOOKING -> BookingScreen(selectedProvider, bookings,
                    onSave = { booking ->
                        val updated = bookings + booking
                        marketplace.saveBookings(updated); bookings = updated
                    },
                    onChat = { selectedProviderId?.let { openChat(it, Screen.BOOKING) } },
                    onBack = { navigate(Screen.MY_BOOKINGS) })
                Screen.MY_BOOKINGS -> MyBookingsScreen(bookings, providers,
                    onCancel = { id ->
                        val updated = bookings.map { if (it.id == id) it.copy(cancelled = true) else it }
                        marketplace.saveBookings(updated); bookings = updated
                    },
                    onOpenChat = { id -> openChat(id, Screen.MY_BOOKINGS) })
                Screen.HELP -> HelpHomeScreen(messages, reports, providers,
                    onCuraAI = { navigate(Screen.SUPPORT_CHAT) },
                    onOpenProviderChat = { id -> openChat(id, Screen.HELP) },
                    onReport = { reportReturnName = Screen.HELP.name; navigate(Screen.SUPPORT_REPORT) })
                Screen.DIRECT_CHAT -> DemoChatScreen(
                    threadId = threadFor(selectedProviderId.orEmpty()),
                    title = "Chat com ${selectedProvider?.name ?: "prestador"}",
                    isSupport = false, messages = messages,
                    onSend = { content ->
                        val newList = (messages + DemoMessage(UUID.randomUUID().toString(),
                            threadFor(selectedProviderId.orEmpty()), MessageAuthor.USER,
                            content, System.currentTimeMillis())).takeLast(500)
                        marketplace.saveMessages(newList); messages = newList
                    },
                    onSimulateReply = {
                        val updated = (messages + DemoMessage(UUID.randomUUID().toString(),
                            threadFor(selectedProviderId.orEmpty()), MessageAuthor.PROVIDER_SIMULATION,
                            "Olá! Podemos conversar sobre outros horários. Esta resposta é simulada neste aparelho, não foi escrita por uma pessoa real.",
                            System.currentTimeMillis())).takeLast(500)
                        marketplace.saveMessages(updated); messages = updated
                    },
                    onReport = {}, onBack = back
                )
                Screen.SUPPORT_CHAT -> DemoChatScreen(SUPPORT_THREAD, "CuraAI", true, messages,
                    onSend = { content ->
                        val now = System.currentTimeMillis()
                        val updated = (messages + listOf(
                            DemoMessage(UUID.randomUUID().toString(), SUPPORT_THREAD,
                                MessageAuthor.USER, content, now),
                            DemoMessage(UUID.randomUUID().toString(), SUPPORT_THREAD,
                                MessageAuthor.SIMULATION, demoSupportReply(content), now + 1)
                        )).takeLast(500)
                        marketplace.saveMessages(updated); messages = updated
                    },
                    onSimulateReply = {},
                    onReport = { reportReturnName = Screen.SUPPORT_CHAT.name; navigate(Screen.SUPPORT_REPORT) },
                    onBack = back
                )
                Screen.SUPPORT_REPORT -> SupportReportScreen(reports, providers,
                    onSave = { report ->
                        val updated = reports + report
                        care.saveReports(updated); reports = updated
                    }, onBack = back)
            }
        }
    }
}

@Composable
private fun RowScope.BottomTab(label: String, symbol: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick,
        icon = { Text(symbol, fontSize = 25.sp, fontWeight = FontWeight.Bold) },
        label = { Text(label, fontSize = 12.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Ink, selectedTextColor = Ink, indicatorColor = MintWhite,
            unselectedIconColor = AquaStrong, unselectedTextColor = Grey))
}

@Composable
private fun CurareHeader(isWelcome: Boolean, showBack: Boolean,
                         onBack: () -> Unit, menuOpen: Boolean,
                         onMenuClick: () -> Unit, onMenuDismiss: () -> Unit,
                         navigate: (Screen) -> Unit) {
    Row(Modifier.fillMaxWidth().background(if (isWelcome) Cloud else Color.White)
        .statusBarsPadding().height(68.dp).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (showBack) {
                TextButton(onClick = onBack, contentPadding = PaddingValues(3.dp)) {
                    Text("‹", color = AquaStrong, fontSize = 36.sp)
                }
            } else {
                IconButton(onClick = onMenuClick) {
                    Text("☰", color = AquaStrong, fontSize = 26.sp)
                }
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = onMenuDismiss) {
                DropdownMenuItem(text = { Text("Início") }, onClick = { navigate(Screen.WELCOME) })
                DropdownMenuItem(text = { Text("Meu perfil") }, onClick = { navigate(Screen.PROFILE) })
                DropdownMenuItem(text = { Text("Histórico") }, onClick = { navigate(Screen.HISTORY) })
                DropdownMenuItem(text = { Text("Meus pedidos") }, onClick = { navigate(Screen.MY_BOOKINGS) })
                DropdownMenuItem(text = { Text("Solicitar serviços") }, onClick = { navigate(Screen.SERVICES) })
                DropdownMenuItem(text = { Text("Conversas e ajuda") }, onClick = { navigate(Screen.HELP) })
                DropdownMenuItem(text = { Text("Editar cadastro") }, onClick = { navigate(Screen.REGISTER) })
            }
        }
        Box(Modifier.weight(2.2f), contentAlignment = Alignment.Center) {
            if (!isWelcome) CurareWordmark()
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
            if (!isWelcome) CatMark(Modifier.size(54.dp))
        }
    }
}
