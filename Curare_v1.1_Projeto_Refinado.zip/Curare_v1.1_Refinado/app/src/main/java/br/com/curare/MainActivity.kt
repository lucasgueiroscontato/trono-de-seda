package br.com.curare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import br.com.curare.data.LocalCareRepository
import br.com.curare.data.LocalMarketplaceRepository
import br.com.curare.data.LocalProfileRepository
import br.com.curare.ui.CurareApp
import br.com.curare.ui.theme.CurareTheme
import br.com.curare.ui.theme.Cloud

/** Ponto de entrada único. A navegação é mantida em Compose. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = LocalProfileRepository(applicationContext)
        val careRepository = LocalCareRepository(applicationContext)
        val marketplaceRepository = LocalMarketplaceRepository(applicationContext)
        setContent {
            CurareTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Cloud) {
                    CurareApp(repository, careRepository, marketplaceRepository)
                }
            }
        }
    }
}
