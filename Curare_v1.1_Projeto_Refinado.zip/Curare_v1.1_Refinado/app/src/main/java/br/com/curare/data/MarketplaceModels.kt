package br.com.curare.data

import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Catálogo totalmente FICTÍCIO. As avaliações e janelas não vêm de pessoas reais. */
enum class CareCategory(val label: String, val shortLabel: String) {
    IDOSOS("Cuidados com idosos", "Idosos"),
    ANIMAIS("Cuidados com animais", "Animais"),
    BABAS("Babás e crianças", "Babás"),
    ACOMPANHAMENTO("Acompanhamento", "Acompanhamento")
}

data class DemoProvider(
    val id: String,
    val name: String,
    val age: Int,
    val categories: Set<CareCategory>,
    val bio: String,
    val rating: Double,
    val reviews: Int,
    val slots: List<AvailabilitySlot>,
    val isOwnLocalProfile: Boolean = false
)

/** Pedido local sem pagamento, aceitação por profissional ou confirmação externa. */
data class DemoBooking(
    val id: String,
    val providerId: String,
    val category: CareCategory,
    val date: String,
    val startsAt: String,
    val endsAt: String,
    val details: String,
    val createdAtMillis: Long,
    val cancelled: Boolean = false
)

enum class MessageAuthor { USER, SIMULATION, PROVIDER_SIMULATION }

data class DemoMessage(
    val id: String,
    val threadId: String,
    val author: MessageAuthor,
    val content: String,
    val createdAtMillis: Long
)

fun sampleProviders(): List<DemoProvider> = listOf(
    DemoProvider("gomes", "Gomes", 28, setOf(CareCategory.IDOSOS, CareCategory.ACOMPANHAMENTO),
        "Acompanhamento de idosos em consultas e atividades cotidianas.", 5.0, 24,
        listOf(AvailabilitySlot(WeekDay.MONDAY, "12:00", "16:00"),
            AvailabilitySlot(WeekDay.WEDNESDAY, "12:00", "16:00"),
            AvailabilitySlot(WeekDay.FRIDAY, "12:00", "16:00"))),
    DemoProvider("renata", "Renata", 18, setOf(CareCategory.IDOSOS, CareCategory.ANIMAIS),
        "Gosto de acompanhar pessoas idosas e cuidar de animais. Estudo e busco horários flexíveis.", 4.8, 19,
        listOf(AvailabilitySlot(WeekDay.TUESDAY, "13:00", "17:00"),
            AvailabilitySlot(WeekDay.THURSDAY, "13:00", "17:00"))),
    DemoProvider("dante", "Dante", 23, setOf(CareCategory.BABAS),
        "Atividades educativas e recreativas com crianças, sempre conforme as orientações familiares.", 4.7, 16,
        listOf(AvailabilitySlot(WeekDay.MONDAY, "14:00", "18:00"),
            AvailabilitySlot(WeekDay.SATURDAY, "09:00", "13:00"))),
    DemoProvider("julia", "Julia", 27, setOf(CareCategory.ACOMPANHAMENTO, CareCategory.IDOSOS),
        "Acompanhamento em consultas e passeios curtos.", 4.6, 31,
        listOf(AvailabilitySlot(WeekDay.TUESDAY, "09:00", "15:00"),
            AvailabilitySlot(WeekDay.FRIDAY, "09:00", "15:00"))),
    DemoProvider("mika", "Mika", 21, setOf(CareCategory.ANIMAIS),
        "Passeios com cães e cuidados rotineiros com animais domésticos.", 4.5, 14,
        listOf(AvailabilitySlot(WeekDay.MONDAY, "08:00", "12:00"),
            AvailabilitySlot(WeekDay.THURSDAY, "16:00", "20:00"))),
    DemoProvider("raquel", "Raquel", 25, setOf(CareCategory.ANIMAIS, CareCategory.ACOMPANHAMENTO),
        "Apoio em passeios com animais e pequenas tarefas do dia a dia.", 3.9, 11,
        listOf(AvailabilitySlot(WeekDay.WEDNESDAY, "15:00", "19:00"),
            AvailabilitySlot(WeekDay.SUNDAY, "15:00", "19:00")))
)

private fun normalized(text: String): String = Normalizer.normalize(text, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)

enum class ProviderOrder { BEST_RATING, MORE_SLOTS }

fun searchProviders(
    providers: List<DemoProvider>,
    query: String,
    category: CareCategory?,
    onlyAvailable: Boolean,
    order: ProviderOrder = ProviderOrder.BEST_RATING
): List<DemoProvider> {
    val needle = normalized(query.trim())
    return providers.filter { provider ->
        (category == null || category in provider.categories) &&
            (!onlyAvailable || provider.slots.isNotEmpty()) &&
            (needle.isBlank() || normalized(provider.name + " " + provider.bio + " " +
                provider.categories.joinToString(" ") { it.label }).contains(needle))
    }.sortedWith(if (order == ProviderOrder.BEST_RATING) {
        compareByDescending<DemoProvider> { it.rating }.thenByDescending { it.slots.size }.thenBy { it.name }
    } else {
        compareByDescending<DemoProvider> { it.slots.size }.thenByDescending { it.rating }.thenBy { it.name }
    })
}

private fun parseDate(date: String): Calendar? {
    if (!validDate(date)) return null
    val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).apply { isLenient = false }
    val parsed = runCatching { formatter.parse(date) }.getOrNull() ?: return null
    return Calendar.getInstance().apply { time = parsed; clearTime() }
}

private fun Calendar.clearTime() {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}

fun formatDate(calendar: Calendar): String =
    SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).format(calendar.time)

fun dayForDate(date: String): WeekDay? = when (parseDate(date)?.get(Calendar.DAY_OF_WEEK)) {
    Calendar.MONDAY -> WeekDay.MONDAY
    Calendar.TUESDAY -> WeekDay.TUESDAY
    Calendar.WEDNESDAY -> WeekDay.WEDNESDAY
    Calendar.THURSDAY -> WeekDay.THURSDAY
    Calendar.FRIDAY -> WeekDay.FRIDAY
    Calendar.SATURDAY -> WeekDay.SATURDAY
    Calendar.SUNDAY -> WeekDay.SUNDAY
    else -> null
}

/** Datas de disponibilidade para os próximos 14 dias, sem representar estoque remoto. */
fun upcomingProviderDates(provider: DemoProvider, now: Calendar = Calendar.getInstance()): List<String> {
    val calendar = (now.clone() as Calendar).apply { clearTime() }
    val result = mutableListOf<String>()
    repeat(14) {
        val date = formatDate(calendar)
        if (provider.slots.any { it.day == dayForDate(date) }) result.add(date)
        calendar.add(Calendar.DATE, 1)
    }
    return result
}

/** Hoje e datas futuras; dia e hora devem corresponder à agenda do prestador. */
fun canRequestBooking(
    provider: DemoProvider,
    date: String,
    startsAt: String,
    endsAt: String,
    bookings: List<DemoBooking>,
    today: Calendar = Calendar.getInstance()
): Boolean {
    val requestedDate = parseDate(date) ?: return false
    val todayDate = (today.clone() as Calendar).apply { clearTime() }
    // A interface exibe apenas as próximas duas semanas: o domínio aplica o mesmo limite.
    if (provider.isOwnLocalProfile || requestedDate.before(todayDate)) return false
    val lastAllowed = (todayDate.clone() as Calendar).apply { add(Calendar.DATE, 13) }
    if (requestedDate.after(lastAllowed)) return false
    if (requestedDate.timeInMillis == todayDate.timeInMillis) {
        val currentHour = String.format(Locale.ROOT, "%02d:%02d",
            today.get(Calendar.HOUR_OF_DAY), today.get(Calendar.MINUTE))
        if (startsAt <= currentHour) return false
    }
    if (!validTime(startsAt) || !validTime(endsAt) || startsAt >= endsAt) return false
    val weekDay = dayForDate(date) ?: return false
    val insideSlot = provider.slots.any {
        it.day == weekDay && startsAt >= it.startsAt && endsAt <= it.endsAt
    }
    if (!insideSlot) return false
    return bookings.none {
        !it.cancelled && it.providerId == provider.id && it.date == date &&
            startsAt < it.endsAt && endsAt > it.startsAt
    }
}

/** Confere disponibilidade real dentro da SIMULAÇÃO, inclusive pedidos locais que já ocupam horários. */
fun hasBookableSlot(
    provider: DemoProvider,
    bookings: List<DemoBooking>,
    now: Calendar = Calendar.getInstance()
): Boolean = upcomingProviderDates(provider, now).any { day ->
    provider.slots.any { slot ->
        slot.day == dayForDate(day) && canRequestBooking(
            provider, day, slot.startsAt, slot.endsAt, bookings, now
        )
    }
}

fun threadFor(providerId: String): String = "provider:$providerId"
const val SUPPORT_THREAD = "support:curai"

/** Chatbot determinístico, local e ilustrativo; não é IA generativa e não envia mensagens. */
fun demoSupportReply(input: String): String {
    val message = normalized(input)
    return when {
        listOf("agress", "violenc", "ameac", "roubo", "perigo", "emergenc").any { it in message } ->
            "Sinto muito por essa situação. Se alguém estiver em perigo agora, procure ajuda de um adulto de confiança ou dos serviços oficiais de emergência. Este chat é apenas uma simulação e não aciona socorro."
        listOf("denunc", "reclam", "conduta", "problema", "ocorrenc").any { it in message } ->
            "Você pode usar o botão 'Registrar ocorrência fictícia' nesta tela. O formulário salva apenas neste aparelho e não encaminha denúncias reais."
        listOf("horario", "agenda", "marcar", "agend", "disponiv").any { it in message } ->
            "Na aba Serviços, escolha um perfil fictício e veja os dias disponíveis. Para outros horários, abra o chat demonstrativo do prestador. Pedidos não são confirmados de verdade."
        listOf("pagament", "preco", "valor", "pix").any { it in message } ->
            "Este protótipo não cobra, recebe pagamentos nem exige documentos. Não compartilhe dados financeiros no chat."
        (Regex("\\boi\\b").containsMatchIn(message) ||
            listOf("ola", "ajuda", "bom dia", "boa tarde", "boa noite").any { it in message }) ->
            "Olá! Sou a CuraAI de demonstração. Posso orientar sobre agenda, pedidos fictícios e o formulário de ocorrências. Nenhuma mensagem é enviada para um atendente."
        else -> "Este é um atendimento automatizado de exemplo. Posso explicar como funcionam agenda, solicitações, chats e ocorrências fictícias. Para problemas reais, procure um canal de suporte humano apropriado."
    }
}

/** Inclui o perfil do próprio prestador na busca, somente no dispositivo. */
fun localProvider(profile: Profile, slots: List<AvailabilitySlot>, records: List<ServiceRecord>): DemoProvider {
    val services = normalized(profile.offeredServices)
    val categories = buildSet {
        if (listOf("idos", "senhor", "terceira idade").any { it in services }) add(CareCategory.IDOSOS)
        if (listOf("animal", "cao", "cachorro", "pet", "gato").any { it in services }) add(CareCategory.ANIMAIS)
        if (listOf("baba", "crianca", "infantil").any { it in services }) add(CareCategory.BABAS)
        if (listOf("acompan", "consulta", "passeio").any { it in services }) add(CareCategory.ACOMPANHAMENTO)
    }.ifEmpty { setOf(CareCategory.ACOMPANHAMENTO) }
    return DemoProvider("meu-perfil-local", profile.name, profile.age ?: 0, categories,
        profile.bio.ifBlank { "Perfil local em preparação: adicione uma descrição na aba Perfil." },
        averageRating(records) ?: 0.0, records.count { it.rating in 1..5 },
        sortedSlots(slots), isOwnLocalProfile = true)
}
