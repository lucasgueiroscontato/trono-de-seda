package br.com.curare.data

/** Perfil de demonstração; nenhuma identidade foi comprovada. */
enum class UserRole(val displayName: String) {
    CLIENTE("Cliente"),
    PRESTADOR("Prestador(a)")
}

data class Profile(
    val name: String,
    val age: Int?,
    val role: UserRole,
    val bio: String = "",
    val offeredServices: String = ""
)
