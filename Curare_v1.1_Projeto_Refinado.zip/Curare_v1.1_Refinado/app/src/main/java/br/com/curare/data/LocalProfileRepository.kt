package br.com.curare.data

import android.content.Context

/** Armazenamento local. Não constitui autenticação nem validação profissional. */
class LocalProfileRepository(context: Context) {
    private val prefs = context.getSharedPreferences("curare_demo_profile", Context.MODE_PRIVATE)

    fun load(): Profile? {
        val name = prefs.getString("name", null)?.trim().orEmpty()
        if (name.isEmpty()) return null
        val role = runCatching {
            UserRole.valueOf(prefs.getString("role", UserRole.CLIENTE.name).orEmpty())
        }.getOrDefault(UserRole.CLIENTE)
        val age = prefs.getInt("age", -1).takeIf { it in 1..120 }
        return Profile(
            name = name,
            age = age,
            role = role,
            bio = prefs.getString("bio", "").orEmpty(),
            offeredServices = prefs.getString("offeredServices", "").orEmpty()
        )
    }

    fun save(profile: Profile) {
        prefs.edit()
            .putString("name", profile.name.trim())
            .putString("role", profile.role.name)
            .putInt("age", profile.age ?: -1)
            .putString("bio", profile.bio.take(500))
            .putString("offeredServices", profile.offeredServices.take(250))
            .apply()
    }
}
