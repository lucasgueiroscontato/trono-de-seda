package br.com.curare.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.ui.theme.*

/** Silhueta neutra em lugar de uma foto: não solicita acesso a câmera/galeria. */
@Composable
fun ProfileAvatar(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .background(MintWhite, RoundedCornerShape(18.dp))
            .border(2.dp, Aqua, RoundedCornerShape(18.dp))
            .semantics { contentDescription = "Imagem ilustrativa do perfil" }
    ) {
        val blueGray = Color(0xFF7C98A7)
        drawCircle(blueGray, radius = size.minDimension * .17f,
            center = Offset(size.width * .5f, size.height * .34f))
        drawRoundRect(
            color = blueGray,
            topLeft = Offset(size.width * .13f, size.height * .61f),
            size = androidx.compose.ui.geometry.Size(size.width * .74f, size.height * .36f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.width * .20f)
        )
    }
}

/** Notas de 1 a 5; quando editable=false as estrelas são informativas. */
@Composable
fun RatingStars(
    rating: Int,
    modifier: Modifier = Modifier,
    editable: Boolean = false,
    onRatingChange: (Int) -> Unit = {}
) {
    Row(modifier = modifier.semantics { contentDescription = "Avaliação $rating de 5 estrelas" },
        horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        (1..5).forEach { star ->
            Box(
                modifier = if (editable) Modifier.size(42.dp)
                    .semantics { contentDescription = "Definir $star estrelas" }
                    .clickable { onRatingChange(star) } else Modifier,
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "★",
                    fontSize = 26.sp,
                    color = if (star <= rating) Color(0xFFF5BC3D) else Color(0xFFB6C0C5)
                )
            }
        }
    }
}

@Composable
fun SectionHeading(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Grey, fontSize = 13.sp)
    }
}

@Composable
fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MintWhite),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}
