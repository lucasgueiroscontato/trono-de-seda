package br.com.curare.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.ui.theme.*

/** Marca de folhas desenhada no Compose: não depende de imagem externa. */
@Composable
fun LeafMark(modifier: Modifier = Modifier, color: Color = Leaf) {
    Canvas(modifier = modifier.semantics { contentDescription = "Folhas do Curare" }) {
        val w = size.width
        val h = size.height
        val leftLeaf = Path().apply {
            moveTo(w * .52f, h * .83f)
            cubicTo(w * .37f, h * .58f, w * .17f, h * .52f, w * .13f, h * .16f)
            cubicTo(w * .38f, h * .10f, w * .63f, h * .33f, w * .52f, h * .83f)
            close()
        }
        val rightLeaf = Path().apply {
            moveTo(w * .52f, h * .72f)
            cubicTo(w * .48f, h * .41f, w * .67f, h * .26f, w * .90f, h * .30f)
            cubicTo(w * .82f, h * .57f, w * .67f, h * .65f, w * .52f, h * .72f)
            close()
        }
        drawPath(leftLeaf, color)
        drawPath(rightLeaf, color)
        drawLine(Color.White.copy(alpha = .63f), Offset(w * .26f, h * .29f), Offset(w * .54f, h * .79f), 2.dp.toPx())
        drawLine(Color.White.copy(alpha = .63f), Offset(w * .84f, h * .37f), Offset(w * .54f, h * .67f), 2.dp.toPx())
        val stem = Path().apply {
            moveTo(w * .54f, h * .71f)
            quadraticTo(w * .58f, h * .89f, w * .51f, h * .98f)
        }
        drawPath(stem, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
    }
}

/** Contorno simpático de gatinho, semelhante ao elemento do protótipo. */
@Composable
fun CatMark(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.semantics { contentDescription = "Mascote gatinho" }) {
        val w = size.width
        val h = size.height
        val blue = Color(0xFFB3D5E5)
        val line = 2.dp.toPx()
        val earsFace = Path().apply {
            moveTo(w * .20f, h * .41f)
            lineTo(w * .26f, h * .13f)
            lineTo(w * .42f, h * .28f)
            quadraticTo(w * .50f, h * .24f, w * .58f, h * .28f)
            lineTo(w * .75f, h * .13f)
            lineTo(w * .82f, h * .42f)
            moveTo(w * .25f, h * .69f)
            quadraticTo(w * .50f, h * .90f, w * .76f, h * .69f)
        }
        drawPath(earsFace, blue, style = Stroke(line, cap = StrokeCap.Round))
        drawCircle(blue, radius = 2.2.dp.toPx(), center = Offset(w * .40f, h * .51f))
        drawCircle(blue, radius = 2.2.dp.toPx(), center = Offset(w * .62f, h * .51f))
        drawCircle(blue, radius = 1.8.dp.toPx(), center = Offset(w * .51f, h * .61f))
        drawLine(blue, Offset(w * .11f, h * .54f), Offset(w * .30f, h * .58f), line)
        drawLine(blue, Offset(w * .10f, h * .67f), Offset(w * .29f, h * .65f), line)
        drawLine(blue, Offset(w * .72f, h * .58f), Offset(w * .92f, h * .54f), line)
        drawLine(blue, Offset(w * .72f, h * .65f), Offset(w * .92f, h * .67f), line)
    }
}

@Composable
fun CurareWordmark() {
    Text(
        text = "curare",
        color = Ink,
        fontSize = 35.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-1).sp,
        textAlign = TextAlign.Center
    )
}

@Composable
fun CurareButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 52.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Aqua,
            contentColor = Ink,
            disabledContainerColor = MintWhite,
            disabledContentColor = Grey
        )
    ) { Text(text, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
}
