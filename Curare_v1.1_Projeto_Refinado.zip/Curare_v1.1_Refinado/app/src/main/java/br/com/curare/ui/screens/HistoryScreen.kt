package br.com.curare.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*
import java.util.UUID

@Composable
fun HistoryScreen(
    records: List<ServiceRecord>,
    reports: List<IncidentReport>,
    onAddRecord: (ServiceRecord) -> Unit,
    onLoadExamples: () -> Unit,
    onOpenDetail: (String) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Seu histórico de serviços", color = Ink, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("Registro e acompanhamento de atendimentos anteriores.", color = Grey, fontSize = 14.sp)
        CurareButton("+ Registrar serviço (demo)", Modifier.fillMaxWidth()) { showAdd = true }
        if (records.isEmpty()) {
            SectionCard {
                Text("Ainda não há serviços no histórico.", color = Ink, fontWeight = FontWeight.SemiBold)
                Text("Para explorar o protótipo, adicione um registro fictício ou carregue exemplos.",
                    color = Grey, fontSize = 14.sp)
                OutlinedButton(onClick = onLoadExamples, modifier = Modifier.fillMaxWidth()) {
                    Text("Carregar exemplos fictícios")
                }
            }
        } else {
            records.forEach { service ->
                SectionCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        ProfileAvatar(Modifier.size(70.dp))
                        Column(Modifier.weight(1f)) {
                            Text(service.personName, fontWeight = FontWeight.SemiBold, color = Ink)
                            Text(service.location, color = Grey, fontSize = 13.sp)
                            Text("${service.date} • ${service.startsAt}–${service.endsAt}",
                                color = Grey, fontSize = 12.sp)
                        }
                    }
                    RatingStars(service.rating)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        if (service.isDemo) {
                            Text("Exemplo fictício", color = Grey, fontSize = 12.sp)
                        } else {
                            Text("Registro local", color = Grey, fontSize = 12.sp)
                        }
                        if (reports.any { it.serviceId == service.id }) {
                            Text("Ocorrência registrada", color = Grey, fontSize = 12.sp)
                        }
                    }
                    OutlinedButton(onClick = { onOpenDetail(service.id) },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text("Ver detalhes da avaliação")
                    }
                }
            }
        }
        Text("Histórico armazenado somente neste aparelho. Não há contratos ou avaliações verificadas.",
            color = Grey, fontSize = 12.sp)
    }
    if (showAdd) {
        AddHistoryDialog(onDismiss = { showAdd = false }, onAdd = {
            onAddRecord(it)
            showAdd = false
        })
    }
}

@Composable
private fun AddHistoryDialog(onDismiss: () -> Unit, onAdd: (ServiceRecord) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var location by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf("") }
    var start by rememberSaveable { mutableStateOf("09:00") }
    var end by rememberSaveable { mutableStateOf("11:00") }
    var rating by rememberSaveable { mutableIntStateOf(5) }
    var review by rememberSaveable { mutableStateOf("") }
    var showErrors by remember { mutableStateOf(false) }
    val record = ServiceRecord(
        id = "preview",
        personName = name.trim(), location = location.trim(), date = date.trim(),
        startsAt = start.trim(), endsAt = end.trim(), rating = rating,
        review = review.trim(), isDemo = true
    )
    val valid = validateRecord(record)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar serviço fictício") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Preencha apenas informações inventadas para testar a interface.",
                    color = Grey, fontSize = 12.sp)
                OutlinedTextField(value = name, onValueChange = { name = it.take(70) },
                    label = { Text("Nome da pessoa") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it.take(100) },
                    label = { Text("Local do serviço") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = date, onValueChange = { date = it.take(10) },
                    label = { Text("Data (DD/MM/AAAA)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = start, onValueChange = { start = it.take(5) },
                        label = { Text("Início") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = end, onValueChange = { end = it.take(5) },
                        label = { Text("Fim") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Text("Nota atribuída ao serviço (1 a 5)", color = Ink, fontSize = 14.sp)
                RatingStars(rating, editable = true, onRatingChange = { rating = it })
                OutlinedTextField(value = review, onValueChange = { review = it.take(500) },
                    label = { Text("Avaliação (opcional)") }, minLines = 2,
                    modifier = Modifier.fillMaxWidth())
                if (showErrors && !valid) {
                    Text("Confira nome, local, data válida, início anterior ao fim e nota.",
                        color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = { showErrors = true; if (valid) onAdd(record.copy(id = "local-${UUID.randomUUID()}")) }) {
            Text("Salvar")
        } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun HistoryDetailScreen(
    service: ServiceRecord?,
    reported: Boolean,
    onGoBack: () -> Unit,
    onReport: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        if (service == null) {
            Text("Serviço não encontrado.", color = Ink)
            OutlinedButton(onClick = onGoBack) { Text("Voltar ao histórico") }
            return@Column
        }
        Text("Detalhes do serviço", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ProfileAvatar(Modifier.size(94.dp))
                Column {
                    Text(service.personName, fontWeight = FontWeight.Bold, color = Ink, fontSize = 20.sp)
                    Text(service.location, fontSize = 14.sp, color = Grey)
                    Text("${service.date} • ${service.startsAt} às ${service.endsAt}",
                        fontSize = 13.sp, color = Grey)
                }
            }
        }
        SectionCard {
            SectionHeading("Sua avaliação")
            RatingStars(service.rating)
            Text(service.review.ifBlank { "Nenhum comentário registrado." }, color = Ink)
            if (service.isDemo) Text("Dados fictícios para apresentação acadêmica.",
                fontSize = 12.sp, color = Grey)
        }
        SectionCard {
            SectionHeading("Comportamento inadequado?")
            Text("Registre uma ocorrência fictícia relacionada a este atendimento. Nenhum aviso é enviado à equipe do aplicativo ou às autoridades.",
                color = Grey, fontSize = 14.sp)
            CurareButton(if (reported) "Ocorrência já registrada" else "Registrar ocorrência (demo)",
                Modifier.fillMaxWidth(), enabled = !reported, onClick = onReport)
        }
        OutlinedButton(onClick = onGoBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar ao histórico") }
    }
}
