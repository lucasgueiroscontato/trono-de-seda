package br.com.curare.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Aqua = Color(0xFF88DCE8)
val AquaStrong = Color(0xFF53BACC)
val Cloud = Color(0xFFD4F5F9)
val MintWhite = Color(0xFFF2FCFC)
val Leaf = Color(0xFFB7DB9F)
val Ink = Color(0xFF253034)
val Grey = Color(0xFF506972) // Contraste aprimorado para legendas em fundo claro

private val CurareColors = lightColorScheme(
    primary = AquaStrong,
    onPrimary = Ink,
    secondary = Leaf,
    onSecondary = Ink,
    background = Color.White,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = MintWhite,
    onSurfaceVariant = Grey,
    outline = Aqua
)

@Composable
fun CurareTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CurareColors, content = content)
}
