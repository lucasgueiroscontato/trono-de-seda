package br.com.curare.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*
import java.util.Locale
import java.util.UUID

/** Busca no catálogo interno; não faz requisições nem identifica pessoas reais. */
@Composable
fun ServicesScreen(
    providers: List<DemoProvider>,
    bookings: List<DemoBooking>,
    onOpenProvider: (String) -> Unit,
    onMyBookings: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var categoryName by rememberSaveable { mutableStateOf("ALL") }
    var freeOnly by rememberSaveable { mutableStateOf(true) }
    var orderName by rememberSaveable { mutableStateOf(ProviderOrder.BEST_RATING.name) }
    val category = CareCategory.entries.firstOrNull { it.name == categoryName }
    val order = ProviderOrder.valueOf(orderName)
    val filtered = remember(query, category, freeOnly, order, providers, bookings) {
        searchProviders(providers, query, category, freeOnly, order).filter { provider ->
            !freeOnly || hasBookableSlot(provider, bookings) ||
                (provider.isOwnLocalProfile && provider.slots.isNotEmpty())
        }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Encontre seu cuidado", fontSize = 25.sp, color = Ink, fontWeight = FontWeight.Bold)
            Text("Explore profissionais fictícios, avaliações e horários de exemplo.", fontSize = 13.sp, color = Grey)
            OutlinedTextField(
                value = query, onValueChange = { query = it.take(80) },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Buscar por nome ou serviço") },
                placeholder = { Text("Ex.: idosos, animais, Gomes") },
                shape = RoundedCornerShape(18.dp)
            )
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf<Pair<String, String>>("ALL" to "Todos")
                    .plus(CareCategory.entries.map { it.name to it.shortLabel }).forEach { (name, label) ->
                        FilterChip(selected = categoryName == name, onClick = { categoryName = name },
                            label = { Text(label) })
                    }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = freeOnly, onClick = { freeOnly = !freeOnly },
                    label = { Text("Com horário livre") })
                Text("Ordenar:", fontSize = 12.sp, color = Grey)
                Box {
                    var orderOpen by remember { mutableStateOf(false) }
                    TextButton(onClick = { orderOpen = true }) {
                        Text(if (order == ProviderOrder.BEST_RATING) "Melhor nota" else "Mais horários")
                    }
                    DropdownMenu(expanded = orderOpen, onDismissRequest = { orderOpen = false }) {
                        DropdownMenuItem(text = { Text("Melhor nota") }, onClick = {
                            orderName = ProviderOrder.BEST_RATING.name; orderOpen = false
                        })
                        DropdownMenuItem(text = { Text("Mais horários") }, onClick = {
                            orderName = ProviderOrder.MORE_SLOTS.name; orderOpen = false
                        })
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("${filtered.size} perfil(is) • catálogo local", color = Grey, fontSize = 12.sp)
                TextButton(onClick = onMyBookings) { Text("Meus pedidos") }
            }
        }
        HorizontalDivider(color = Aqua.copy(alpha = .45f))
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Nenhum perfil encontrado", color = Ink, fontWeight = FontWeight.SemiBold)
                Text("Tente outra categoria, termo de busca ou desative o filtro de agenda.", color = Grey)
                OutlinedButton(onClick = { query = ""; categoryName = "ALL"; freeOnly = false }) {
                    Text("Limpar filtros")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { provider ->
                    ProviderCard(provider) { onOpenProvider(provider.id) }
                }
                item { Text("Os perfis, estrelas e horários são exemplos. Não é possível contratar pessoas reais.",
                    color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
    }
}

@Composable
private fun ProviderCard(provider: DemoProvider, onOpen: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, Aqua.copy(alpha = .55f)),
        colors = CardDefaults.cardColors(containerColor = MintWhite)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(Modifier.size(76.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(provider.name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(if (provider.isOwnLocalProfile) "Seu perfil • apenas neste celular" else
                        provider.categories.joinToString(" • ") { it.shortLabel }, color = Grey, fontSize = 12.sp)
                    Text(if (provider.reviews == 0) "Ainda sem avaliações" else
                        "★ ${String.format(Locale.forLanguageTag("pt-BR"), "%.1f", provider.rating)}  •  ${provider.reviews} notas locais/demo",
                        color = Ink, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
            }
            Text(provider.bio, color = Ink, fontSize = 14.sp, maxLines = 2)
            val first = sortedSlots(provider.slots).firstOrNull()
            if (first != null) Text("Agenda: ${first.day.compact} ${first.startsAt}–${first.endsAt}  •  ${provider.slots.size} faixa(s)/semana",
                color = Grey, fontSize = 12.sp)
            CurareButton(if (provider.isOwnLocalProfile) "Ver meu anúncio local" else "Ver perfil e horários", Modifier.fillMaxWidth(), onClick = onOpen)
        }
    }
}

@Composable
fun ProviderDetailsScreen(provider: DemoProvider?, onBack: () -> Unit,
                          onBook: () -> Unit, onChat: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        if (provider == null) {
            Text("Perfil indisponível.", color = Ink)
            OutlinedButton(onClick = onBack) { Text("Voltar") }
            return@Column
        }
        SectionCard {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(Modifier.size(100.dp))
                Column(Modifier.weight(1f)) {
                    Text(provider.name, fontWeight = FontWeight.Bold, color = Ink, fontSize = 25.sp)
                    Text(if (provider.isOwnLocalProfile) "Meu perfil • visível só neste aparelho" else
                        "${provider.age} anos • Perfil demonstrativo", color = Grey, fontSize = 12.sp)
                    Text(if (provider.reviews == 0) "Sem avaliações" else
                        "★ ${String.format(Locale.forLanguageTag("pt-BR"), "%.1f", provider.rating)} / 5",
                        color = Ink, fontWeight = FontWeight.Medium)
                    Text("${provider.reviews} avaliações ${if (provider.isOwnLocalProfile) "locais" else "simuladas"}",
                        color = Grey, fontSize = 12.sp)
                }
            }
        }
        SectionCard {
            SectionHeading("Quem é ${provider.name}?")
            Text(provider.bio, color = Ink)
            Text("Serviços: ${provider.categories.joinToString(", ") { it.label }}", color = Grey, fontSize = 13.sp)
        }
        SectionCard {
            SectionHeading("Agenda semanal", "Horários ilustrativos recorrentes")
            sortedSlots(provider.slots).forEach { slot ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(slot.day.label, color = Ink, fontSize = 14.sp)
                    Text("${slot.startsAt}–${slot.endsAt}", color = Grey, fontSize = 14.sp)
                }
            }
        }
        if (provider.isOwnLocalProfile) {
            Text("Este anúncio mostra sua própria agenda local; não é possível contratar a si mesmo.",
                color = Grey, fontSize = 13.sp)
        } else {
            CurareButton("Solicitar horário (demo)", Modifier.fillMaxWidth(), onClick = onBook)
            OutlinedButton(onClick = onChat, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Text("Conversar / horário personalizado")
            }
        }
        Text("Nenhum prestador receberá mensagens ou pedidos. Perfis e avaliações fictícios.",
            color = Grey, fontSize = 12.sp)
    }
}

@Composable
fun BookingScreen(provider: DemoProvider?, bookings: List<DemoBooking>,
                  onSave: (DemoBooking) -> Unit, onChat: () -> Unit, onBack: () -> Unit) {
    if (provider == null) {
        Column(Modifier.padding(18.dp)) {
            Text("Prestador não encontrado.", color = Ink)
            OutlinedButton(onClick = onBack) { Text("Voltar") }
        }
        return
    }
    val dates = remember(provider) { upcomingProviderDates(provider) }
    var date by rememberSaveable(provider.id) { mutableStateOf(dates.firstOrNull().orEmpty()) }
    val daySlots = provider.slots.filter { it.day == dayForDate(date) }
    var slotName by rememberSaveable(provider.id) { mutableStateOf("") }
    val selected = daySlots.firstOrNull { "${it.startsAt}|${it.endsAt}" == slotName }
        ?: daySlots.firstOrNull {
            canRequestBooking(provider, date, it.startsAt, it.endsAt, bookings)
        } ?: daySlots.firstOrNull()
    var detail by rememberSaveable(provider.id) { mutableStateOf("") }
    var completed by rememberSaveable(provider.id) { mutableStateOf(false) }
    val allowed = selected != null && canRequestBooking(
        provider, date, selected.startsAt, selected.endsAt, bookings
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Solicitar serviço", fontSize = 25.sp, color = Ink, fontWeight = FontWeight.Bold)
        Text("Com ${provider.name} • ${provider.categories.first().label}", color = Grey)
        SectionCard {
            SectionHeading("1. Escolha um dia", "Próximos 14 dias com agenda indicativa")
            if (dates.isEmpty()) Text("Sem horário para as próximas duas semanas.", color = Grey)
            else {
                // Rolagem horizontal mantém as datas acessíveis em celulares estreitos.
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    dates.forEach { d ->
                        FilterChip(selected = d == date, onClick = { date = d; slotName = "" },
                            label = { Text(d.substring(0, 5), fontSize = 13.sp) })
                    }
                }
                Text("Deslize para ver outros dias", color = Grey, fontSize = 12.sp)
            }
        }
        SectionCard {
            SectionHeading("2. Selecione o horário")
            if (daySlots.isEmpty()) Text("Selecione um dia disponível.", color = Grey)
            daySlots.forEach { slot ->
                val isFree = canRequestBooking(provider, date, slot.startsAt, slot.endsAt, bookings)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == slot, onClick = {
                        slotName = "${slot.startsAt}|${slot.endsAt}"
                    }, enabled = isFree)
                    Column(Modifier.weight(1f)) {
                        Text("${slot.startsAt} às ${slot.endsAt}", color = Ink)
                        Text(if (isFree) "Disponível na simulação" else "Indisponível neste aparelho",
                            fontSize = 12.sp, color = Grey)
                    }
                }
            }
            OutlinedButton(onClick = onChat, modifier = Modifier.fillMaxWidth()) {
                Text("Outro horário? Conversar (demo)")
            }
        }
        SectionCard {
            SectionHeading("3. Observações (opcional)")
            OutlinedTextField(value = detail, onValueChange = { detail = it.take(250) },
                modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                label = { Text("Detalhes fictícios do atendimento") },
                supportingText = { Text("${detail.length}/250 • Não inclua dados pessoais") })
        }
        CurareButton("Registrar pedido de demonstração", Modifier.fillMaxWidth(), enabled = allowed) {
            val slot = selected ?: return@CurareButton
            // Revalidação no clique, além da propriedade enabled do botão.
            if (!canRequestBooking(provider, date, slot.startsAt, slot.endsAt, bookings))
                return@CurareButton
            onSave(DemoBooking(UUID.randomUUID().toString(), provider.id,
                provider.categories.first(), date, slot.startsAt, slot.endsAt, detail.trim(),
                System.currentTimeMillis()))
            completed = true
        }
        if (!allowed) Text("Escolha uma data futura e um intervalo livre na agenda simulada.",
            fontSize = 12.sp, color = Grey)
        Text("O pedido ficará somente no aparelho. Não há aceitação por prestador, preço ou pagamento.",
            fontSize = 12.sp, color = Grey)
    }
    if (completed) AlertDialog(onDismissRequest = { completed = false; onBack() },
        title = { Text("Pedido de teste registrado") },
        text = { Text("O registro foi salvo localmente. Nenhum prestador foi notificado e não há agendamento confirmado.") },
        confirmButton = { TextButton(onClick = { completed = false; onBack() }) { Text("Entendi") } })
}

@Composable
fun MyBookingsScreen(bookings: List<DemoBooking>, providers: List<DemoProvider>,
                     onCancel: (String) -> Unit, onOpenChat: (String) -> Unit) {
    var pendingCancellation by rememberSaveable { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Meus pedidos", color = Ink, fontWeight = FontWeight.Bold, fontSize = 25.sp)
        Text("Solicitações fictícias guardadas neste dispositivo.", color = Grey, fontSize = 13.sp)
        if (bookings.isEmpty()) SectionCard {
            Text("Você ainda não registrou pedidos.", color = Ink)
            Text("Acesse Serviços e escolha um perfil e horário de exemplo.", color = Grey)
        }
        bookings.sortedByDescending { it.createdAtMillis }.forEach { booking ->
            val name = providers.firstOrNull { it.id == booking.providerId }?.name ?: "Perfil demonstrativo"
            SectionCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (booking.cancelled) "Cancelado" else "Pedido local",
                        color = Grey, fontSize = 12.sp)
                }
                Text(booking.category.label, color = Grey, fontSize = 13.sp)
                Text("${booking.date} • ${booking.startsAt}–${booking.endsAt}", color = Ink)
                if (booking.details.isNotBlank()) Text(booking.details, color = Grey, fontSize = 13.sp)
                if (!booking.cancelled) {
                    OutlinedButton(onClick = { pendingCancellation = booking.id }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cancelar pedido local")
                    }
                }
                OutlinedButton(onClick = { onOpenChat(booking.providerId) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Abrir conversa demonstrativa")
                }
            }
        }
        Text("Cancelar apenas muda o estado no aparelho; não altera agenda de terceiros.", color = Grey, fontSize = 12.sp)
    }
    if (pendingCancellation != null) {
        AlertDialog(
            onDismissRequest = { pendingCancellation = null },
            title = { Text("Cancelar pedido local?") },
            text = { Text("O horário será liberado nesta demonstração. Nenhum prestador real será notificado.") },
            dismissButton = { TextButton(onClick = { pendingCancellation = null }) { Text("Voltar") } },
            confirmButton = { TextButton(onClick = {
                pendingCancellation?.let(onCancel)
                pendingCancellation = null
            }) { Text("Confirmar cancelamento") } }
        )
    }
}
