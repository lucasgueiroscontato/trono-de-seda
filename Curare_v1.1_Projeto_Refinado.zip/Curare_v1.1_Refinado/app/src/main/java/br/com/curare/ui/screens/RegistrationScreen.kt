package br.com.curare.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.CurareButton
import br.com.curare.ui.theme.*

/** Formulário de perfil LOCAL. Não solicita senha ou documentos. */
@Composable
fun RegistrationScreen(existing: Profile?, onSave: (Profile) -> Unit) {
    var name by rememberSaveable(existing) { mutableStateOf(existing?.name.orEmpty()) }
    var age by rememberSaveable(existing) { mutableStateOf(existing?.age?.toString().orEmpty()) }
    var roleName by rememberSaveable(existing) { mutableStateOf(existing?.role?.name ?: UserRole.CLIENTE.name) }
    var showErrors by rememberSaveable { mutableStateOf(false) }
    val role = UserRole.valueOf(roleName)
    val validName = isValidDisplayName(name)
    val validAge = isValidAgeField(age)

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Seu espaço no Curare", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Escolha como deseja usar o aplicativo.", color = Grey)
        Text("Eu sou...", fontWeight = FontWeight.SemiBold, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RoleCard(
                "Cliente", "Quero solicitar cuidados e outros serviços",
                selected = role == UserRole.CLIENTE,
                modifier = Modifier.weight(1f),
                onClick = { roleName = UserRole.CLIENTE.name }
            )
            RoleCard(
                "Prestador(a)", "Quero oferecer meu trabalho",
                selected = role == UserRole.PRESTADOR,
                modifier = Modifier.weight(1f),
                onClick = { roleName = UserRole.PRESTADOR.name }
            )
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(70) },
            label = { Text("Nome de exibição") },
            placeholder = { Text("Como você gostaria de ser chamado?") },
            singleLine = true,
            isError = showErrors && !validName,
            supportingText = if (showErrors && !validName) ({ Text("Informe ao menos 2 caracteres.") }) else null,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp)
        )
        OutlinedTextField(
            value = age,
            onValueChange = { age = it.filter(Char::isDigit).take(3) },
            label = { Text("Idade (opcional)") },
            singleLine = true,
            isError = showErrors && !validAge,
            supportingText = if (showErrors && !validAge) ({ Text("Informe uma idade válida ou deixe em branco.") }) else null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = MintWhite),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Verificação com Gov.br", fontWeight = FontWeight.SemiBold, color = Ink)
                Spacer(Modifier.height(4.dp))
                Text("Recurso ilustrativo. Não realiza conexão, autenticação ou verificação de identidade nesta demonstração.", color = Grey, fontSize = 13.sp)
                Spacer(Modifier.height(9.dp))
                OutlinedButton(onClick = {}, enabled = false) { Text("Verificação indisponível (demo)") }
            }
        }
        CurareButton("Salvar e continuar", modifier = Modifier.fillMaxWidth()) {
            showErrors = true
            if (validName && validAge) {
                onSave(existing?.copy(name = name.trim(), age = parseOptionalAge(age), role = role)
                    ?: Profile(name.trim(), parseOptionalAge(age), role))
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun RoleCard(
    title: String,
    description: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.heightIn(min = 134.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(19.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) AquaStrong else Aqua),
        colors = CardDefaults.cardColors(containerColor = if (selected) Cloud else MintWhite)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(if (selected) "●" else "○", color = AquaStrong, fontSize = 22.sp)
            Text(title, fontWeight = FontWeight.SemiBold, color = Ink)
            Text(description, fontSize = 12.sp, color = Grey, lineHeight = 16.sp)
        }
    }
}
