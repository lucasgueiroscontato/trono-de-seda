package br.com.curare.data

import java.text.SimpleDateFormat
import java.util.Locale

/** Os horários são locais, semanais e não representam agendamentos confirmados. */
enum class WeekDay(val label: String, val compact: String) {
    MONDAY("Segunda-feira", "Seg"),
    TUESDAY("Terça-feira", "Ter"),
    WEDNESDAY("Quarta-feira", "Qua"),
    THURSDAY("Quinta-feira", "Qui"),
    FRIDAY("Sexta-feira", "Sex"),
    SATURDAY("Sábado", "Sáb"),
    SUNDAY("Domingo", "Dom")
}

data class AvailabilitySlot(val day: WeekDay, val startsAt: String, val endsAt: String)

data class ServiceRecord(
    val id: String,
    val personName: String,
    val location: String,
    val date: String,
    val startsAt: String,
    val endsAt: String,
    val rating: Int,
    val review: String,
    val isDemo: Boolean = false
)

data class IncidentReport(
    val id: String,
    val serviceId: String,
    val type: String,
    val description: String,
    val createdAtMillis: Long
)

/** Média somente de avaliações cadastradas neste dispositivo (não verificadas). */
fun averageRating(records: List<ServiceRecord>): Double? =
    records.map { it.rating }.filter { it in 1..5 }.takeIf { it.isNotEmpty() }?.average()

fun validTime(value: String): Boolean {
    val match = Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$").matches(value)
    return match
}

fun validDate(value: String): Boolean {
    if (!Regex("^\\d{2}/\\d{2}/\\d{4}$").matches(value)) return false
    return runCatching {
        val parser = SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR"))
        parser.isLenient = false
        parser.parse(value) != null
    }.getOrDefault(false)
}

private fun toMinutes(value: String): Int =
    value.substring(0, 2).toInt() * 60 + value.substring(3, 5).toInt()

/** Rejeita horário invertido, duplicado ou sobreposto; permite intervalos adjacentes. */
fun canAddSlot(newSlot: AvailabilitySlot, existing: List<AvailabilitySlot>): Boolean {
    if (!validTime(newSlot.startsAt) || !validTime(newSlot.endsAt)) return false
    val start = toMinutes(newSlot.startsAt)
    val end = toMinutes(newSlot.endsAt)
    if (start >= end) return false
    return existing.none { old ->
        old.day == newSlot.day &&
            validTime(old.startsAt) && validTime(old.endsAt) &&
            start < toMinutes(old.endsAt) && end > toMinutes(old.startsAt)
    }
}

fun sortedSlots(slots: List<AvailabilitySlot>): List<AvailabilitySlot> =
    slots.sortedWith(compareBy({ it.day.ordinal }, { it.startsAt }))

fun validateRecord(record: ServiceRecord): Boolean =
    record.id.isNotBlank() && record.personName.trim().length in 2..70 &&
        record.location.trim().length in 2..100 && validDate(record.date) &&
        validTime(record.startsAt) && validTime(record.endsAt) &&
        record.startsAt < record.endsAt && record.rating in 1..5 &&
        record.review.length <= 500

/** Exemplos explicitamente fictícios, ativados manualmente no histórico. */
fun sampleHistory(): List<ServiceRecord> = listOf(
    ServiceRecord("demo-renata", "Renata", "Hospital II", "02/09/2026", "13:00", "15:00", 4,
        "Foi atenciosa e acompanhou o atendimento de forma adequada.", true),
    ServiceRecord("demo-gomes", "Gomes", "Casa de Jogos B", "08/09/2026", "12:00", "16:00", 5,
        "Atendimento cuidadoso e pontual.", true),
    ServiceRecord("demo-raquel", "Raquel", "Loteria K", "14/09/2026", "15:00", "17:00", 2,
        "O horário combinado não foi cumprido.", true),
    ServiceRecord("demo-julia", "Julia", "Clínica Central", "20/09/2026", "09:00", "11:00", 4,
        "Acompanhamento prestativo e boa comunicação.", true)
)
