package br.com.curare.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.IncidentReport
import br.com.curare.data.ServiceRecord
import br.com.curare.ui.components.CurareButton
import br.com.curare.ui.components.SectionCard
import br.com.curare.ui.theme.*
import java.util.UUID

/** Formulário ilustrativo. NÃO encaminha denúncia real. */
@Composable
fun IncidentReportScreen(
    service: ServiceRecord?,
    onSave: (IncidentReport) -> Unit,
    onBack: () -> Unit
) {
    val types = listOf("Atraso ou ausência", "Conduta inadequada", "Cobrança indevida", "Outro")
    var type by rememberSaveable { mutableStateOf(types.first()) }
    var description by rememberSaveable { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var showError by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Reclamações e denúncias", fontSize = 24.sp, color = Ink, fontWeight = FontWeight.Bold)
        if (service == null) {
            Text("Serviço não encontrado.", color = Grey)
            OutlinedButton(onClick = onBack) { Text("Voltar") }
            return@Column
        }
        SectionCard {
            Text("Serviço: ${service.personName} • ${service.date}", color = Ink,
                fontWeight = FontWeight.Medium)
            Text("DEMONSTRAÇÃO: este registro fica apenas no aparelho. Para uma situação real de risco ou violência, procure suporte humano e os canais oficiais adequados; este aplicativo não tem atendimento ativo.",
                fontSize = 13.sp, color = Grey)
        }
        SectionCard {
            Text("Tipo da ocorrência", color = Ink)
            Box {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)) { Text(type) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    types.forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = {
                            type = option; menuOpen = false
                        })
                    }
                }
            }
            OutlinedTextField(
                value = description,
                onValueChange = { description = it.take(500) },
                label = { Text("Descreva uma situação fictícia") },
                placeholder = { Text("Explique o que aconteceu no exemplo...") },
                supportingText = { Text("${description.length}/500 • mínimo de 10 caracteres") },
                minLines = 4, maxLines = 7,
                isError = showError && description.trim().length < 10,
                modifier = Modifier.fillMaxWidth()
            )
            CurareButton("Salvar ocorrência local", Modifier.fillMaxWidth()) {
                showError = true
                if (description.trim().length >= 10) {
                    onSave(IncidentReport(
                        id = UUID.randomUUID().toString(),
                        serviceId = service.id,
                        type = type,
                        description = description.trim(),
                        createdAtMillis = System.currentTimeMillis()
                    ))
                }
            }
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Cancelar") }
    }
}
