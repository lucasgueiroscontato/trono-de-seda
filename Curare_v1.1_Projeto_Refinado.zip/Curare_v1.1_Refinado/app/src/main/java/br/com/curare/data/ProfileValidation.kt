package br.com.curare.data

/** Regras de cadastro puras: podem ser testadas sem Android. */
fun isValidDisplayName(value: String): Boolean = value.trim().length in 2..70

fun parseOptionalAge(value: String): Int? = value.toIntOrNull()?.takeIf { it in 1..120 }

fun isValidAgeField(value: String): Boolean = value.isBlank() || parseOptionalAge(value) != null
