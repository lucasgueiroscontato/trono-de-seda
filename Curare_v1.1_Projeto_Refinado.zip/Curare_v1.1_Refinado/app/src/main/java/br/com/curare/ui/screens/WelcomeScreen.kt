package br.com.curare.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.Profile
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*

/** Tela de acolhimento, com o foco visual no logotipo. */
@Composable
fun WelcomeScreen(profile: Profile?, onRegister: () -> Unit, onEnter: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Cloud).padding(horizontal = 26.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LeafMark(Modifier.size(112.dp))
            Spacer(Modifier.height(13.dp))
            Text("curare", fontSize = 54.sp, fontWeight = FontWeight.Bold, color = Ink, letterSpacing = (-2).sp)
            Spacer(Modifier.height(12.dp))
            Text("Cuidado que aproxima pessoas.", color = Grey, fontSize = 16.sp, textAlign = TextAlign.Center)
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            CurareButton(
                text = if (profile == null) "Começar" else "Continuar como ${profile.name.substringBefore(' ')}",
                modifier = Modifier.fillMaxWidth(),
                onClick = if (profile == null) onRegister else onEnter
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onRegister,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)
            ) {
                Text(if (profile == null) "Criar meu perfil" else "Editar / trocar perfil", fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(18.dp))
            Text("Protótipo acadêmico • Curare 1.1", color = Grey, fontSize = 12.sp)
        }
    }
}
