package br.com.curare.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*
import java.util.Locale

@Composable
fun ProfileScreen(
    profile: Profile?,
    records: List<ServiceRecord>,
    availability: List<AvailabilitySlot>,
    onRegister: () -> Unit,
    onUpdateBio: (String, String) -> Unit,
    onUpdateAvailability: (List<AvailabilitySlot>) -> Unit,
    onHistory: () -> Unit,
    onCustomTime: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        Text("Meu perfil", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        if (profile == null) {
            SectionCard {
                Text("Você ainda não criou um perfil.", color = Ink)
                CurareButton("Criar perfil", Modifier.fillMaxWidth(), onClick = onRegister)
            }
        } else {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    ProfileAvatar(Modifier.size(110.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Olá, ${profile.name.substringBefore(' ')}!", fontSize = 21.sp,
                            color = Ink, fontWeight = FontWeight.Bold)
                        Text(profile.name, color = Ink, fontSize = 15.sp)
                        Text(buildString {
                            append(profile.role.displayName)
                            profile.age?.let { append(" • $it anos") }
                        }, color = Grey, fontSize = 13.sp)
                    }
                }
                OutlinedButton(onClick = onRegister, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)) { Text("Editar nome, idade ou tipo de perfil") }
            }

            val avg = averageRating(records)
            SectionCard {
                SectionHeading("Sua avaliação", "Baseada no histórico salvo neste aparelho")
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    RatingStars(rating = avg?.let { kotlin.math.round(it).toInt() } ?: 0)
                    Text(if (avg == null) "Sem avaliações" else String.format(Locale("pt", "BR"), "%.1f/5", avg),
                        color = Ink, fontWeight = FontWeight.SemiBold)
                }
                Text("${records.count { it.rating in 1..5 }} avaliação(ões) locais. Notas ilustrativas ou inseridas no modo demonstração.",
                    fontSize = 12.sp, color = Grey)
            }

            var editBio by rememberSaveable(profile.name, profile.role.name) { mutableStateOf(false) }
            var draftBio by rememberSaveable(profile.name, profile.role.name) { mutableStateOf(profile.bio) }
            var draftServices by rememberSaveable(profile.name, profile.role.name) {
                mutableStateOf(profile.offeredServices)
            }
            SectionCard {
                SectionHeading("Quem é você?", "Apresente seus cuidados e experiências")
                if (editBio) {
                    OutlinedTextField(
                        value = draftBio, onValueChange = { draftBio = it.take(500) },
                        label = { Text("Sua descrição") },
                        supportingText = { Text("${draftBio.length}/500") },
                        minLines = 3, maxLines = 7,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = draftServices, onValueChange = { draftServices = it.take(250) },
                        label = { Text("Serviços oferecidos") },
                        placeholder = { Text("Ex.: acompanhante de idosos, passeador(a) de cães") },
                        supportingText = { Text("${draftServices.length}/250") },
                        minLines = 2, maxLines = 4,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            draftBio = profile.bio; draftServices = profile.offeredServices
                            editBio = false
                        }, modifier = Modifier.weight(1f)) { Text("Cancelar") }
                        CurareButton("Salvar", Modifier.weight(1f)) {
                            onUpdateBio(draftBio.trim(), draftServices.trim())
                            editBio = false
                        }
                    }
                } else {
                    Text(profile.bio.ifBlank { "Adicione uma descrição para seu perfil." },
                        color = Ink, fontSize = 15.sp)
                    if (profile.offeredServices.isNotBlank()) {
                        HorizontalDivider(color = Aqua)
                        Text("Serviços: ${profile.offeredServices}", color = Ink, fontSize = 14.sp)
                    }
                    OutlinedButton(onClick = { editBio = true }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)) { Text("Alterar descrição e serviços") }
                }
            }

            if (profile.role == UserRole.PRESTADOR) {
                AvailabilitySection(availability, onUpdateAvailability, onCustomTime)
            } else {
                SectionCard {
                    SectionHeading("Sua agenda", "Disponibilidade é configurada em perfis de prestador")
                    Text("Para abrir horários de atendimento, altere o tipo de perfil para Prestador(a).",
                        color = Grey, fontSize = 14.sp)
                }
            }
            SectionCard {
                SectionHeading("Seu histórico de serviços", "Consulte registros, avaliações e ocorrências")
                Text(if (records.isEmpty()) "Ainda não há registros locais." else
                    "${records.size} serviço(s) no histórico.", color = Grey, fontSize = 14.sp)
                CurareButton("Ver histórico completo", Modifier.fillMaxWidth(), onClick = onHistory)
            }
            Text("Protótipo acadêmico • Identidades, avaliações e serviços não verificados.",
                fontSize = 12.sp, color = Grey)
        }
    }
}
