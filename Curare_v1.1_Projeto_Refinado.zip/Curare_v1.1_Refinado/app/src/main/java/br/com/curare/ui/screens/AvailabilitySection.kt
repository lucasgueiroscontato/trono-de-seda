package br.com.curare.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*

@Composable
fun AvailabilitySection(
    slots: List<AvailabilitySlot>,
    onUpdate: (List<AvailabilitySlot>) -> Unit,
    onCustomTime: () -> Unit
) {
    var addDialog by remember { mutableStateOf(false) }
    SectionCard {
        SectionHeading("Agenda aberta", "Dias e horários em que você está disponível")
        if (slots.isEmpty()) {
            Text("Nenhum horário cadastrado. Adicione intervalos para montar sua agenda.",
                color = Grey, fontSize = 14.sp)
        } else {
            sortedSlots(slots).forEach { slot ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(slot.day.label, color = Ink, fontSize = 14.sp)
                        Text("${slot.startsAt} às ${slot.endsAt}", color = Grey, fontSize = 13.sp)
                    }
                    TextButton(onClick = { onUpdate(slots - slot) }) { Text("Remover") }
                }
                HorizontalDivider(color = Aqua.copy(alpha = .4f))
            }
        }
        CurareButton("+ Adicionar horário", Modifier.fillMaxWidth()) { addDialog = true }
        OutlinedButton(onClick = onCustomTime, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)) { Text("Ver conversas e ajuda (demo)") }
        Text("Disponibilidade indicativa, sem confirmação automática de agendamento.",
            fontSize = 12.sp, color = Grey)
    }
    if (addDialog) {
        AddAvailabilityDialog(slots,
            onDismiss = { addDialog = false },
            onAdd = { item -> onUpdate(sortedSlots(slots + item)); addDialog = false })
    }
}

@Composable
private fun AddAvailabilityDialog(
    existing: List<AvailabilitySlot>,
    onDismiss: () -> Unit,
    onAdd: (AvailabilitySlot) -> Unit
) {
    var dayName by rememberSaveable { mutableStateOf(WeekDay.MONDAY.name) }
    var from by rememberSaveable { mutableStateOf("09:00") }
    var to by rememberSaveable { mutableStateOf("12:00") }
    var chooseDay by remember { mutableStateOf(false) }
    var showErrors by remember { mutableStateOf(false) }
    val day = WeekDay.valueOf(dayName)
    val candidate = AvailabilitySlot(day, from.trim(), to.trim())
    val valid = canAddSlot(candidate, existing)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo horário disponível") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Dia da semana", color = Ink)
                Box {
                    OutlinedButton(onClick = { chooseDay = true }) { Text(day.label) }
                    DropdownMenu(expanded = chooseDay, onDismissRequest = { chooseDay = false }) {
                        WeekDay.entries.forEach { item ->
                            DropdownMenuItem(text = { Text(item.label) }, onClick = {
                                dayName = item.name; chooseDay = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    value = from, onValueChange = { from = it.take(5) },
                    label = { Text("Início (HH:mm)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    isError = showErrors && !validTime(from)
                )
                OutlinedTextField(
                    value = to, onValueChange = { to = it.take(5) },
                    label = { Text("Fim (HH:mm)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    isError = showErrors && !validTime(to)
                )
                if (showErrors && !valid) {
                    Text("Use HH:mm (00:00–23:59), término após início, sem horários sobrepostos.",
                        color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { showErrors = true; if (valid) onAdd(candidate) }) {
                Text("Adicionar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
