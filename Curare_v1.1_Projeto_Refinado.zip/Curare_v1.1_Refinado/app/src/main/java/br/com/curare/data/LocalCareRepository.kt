package br.com.curare.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Dados de demonstração salvos apenas no aparelho por SharedPreferences.
 * Não transmite relatórios, mensagens, avaliações ou horários para uma API.
 * Formulários não são adequados ao armazenamento de denúncias reais.
 */
class LocalCareRepository(context: Context) {
    private val prefs = context.getSharedPreferences("curare_phase2", Context.MODE_PRIVATE)

    fun loadAvailability(): List<AvailabilitySlot> = readArray("availability") { obj ->
        val day = WeekDay.valueOf(obj.getString("day"))
        AvailabilitySlot(day, obj.getString("start"), obj.getString("end"))
    }.filter { validTime(it.startsAt) && validTime(it.endsAt) && it.startsAt < it.endsAt }

    fun saveAvailability(slots: List<AvailabilitySlot>) {
        val json = JSONArray()
        sortedSlots(slots).forEach { slot ->
            json.put(JSONObject().put("day", slot.day.name)
                .put("start", slot.startsAt).put("end", slot.endsAt))
        }
        prefs.edit().putString("availability", json.toString()).apply()
    }

    fun loadHistory(): List<ServiceRecord> = readArray("history") { obj ->
        ServiceRecord(
            id = obj.getString("id"),
            personName = obj.getString("personName"),
            location = obj.getString("location"),
            date = obj.getString("date"),
            startsAt = obj.getString("start"),
            endsAt = obj.getString("end"),
            rating = obj.getInt("rating"),
            review = obj.optString("review", ""),
            isDemo = obj.optBoolean("isDemo", false)
        )
    }.filter(::validateRecord)

    fun saveHistory(records: List<ServiceRecord>) {
        val json = JSONArray()
        records.forEach { r ->
            json.put(JSONObject().put("id", r.id)
                .put("personName", r.personName).put("location", r.location)
                .put("date", r.date).put("start", r.startsAt).put("end", r.endsAt)
                .put("rating", r.rating).put("review", r.review).put("isDemo", r.isDemo))
        }
        prefs.edit().putString("history", json.toString()).apply()
    }

    fun loadReports(): List<IncidentReport> = readArray("reports") { obj ->
        IncidentReport(
            obj.getString("id"), obj.getString("serviceId"),
            obj.getString("type"), obj.getString("description"),
            obj.getLong("createdAtMillis")
        )
    }

    fun saveReports(reports: List<IncidentReport>) {
        val json = JSONArray()
        reports.forEach { r ->
            json.put(JSONObject().put("id", r.id).put("serviceId", r.serviceId)
                .put("type", r.type).put("description", r.description)
                .put("createdAtMillis", r.createdAtMillis))
        }
        prefs.edit().putString("reports", json.toString()).apply()
    }

    private fun <T> readArray(key: String, parse: (JSONObject) -> T): List<T> {
        val json = runCatching { JSONArray(prefs.getString(key, "[]") ?: "[]") }.getOrNull() ?: return emptyList()
        return (0 until json.length()).mapNotNull { i ->
            runCatching { parse(json.getJSONObject(i)) }.getOrNull()
        }
    }
}
