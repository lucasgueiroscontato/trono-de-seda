package br.com.curare.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Salva os pedidos e mensagens SOMENTE no aparelho. Sem INTERNET no manifesto. */
class LocalMarketplaceRepository(context: Context) {
    private val prefs = context.getSharedPreferences("curare_phase3", Context.MODE_PRIVATE)

    fun loadBookings(): List<DemoBooking> = readArray("bookings") { obj ->
        DemoBooking(
            obj.getString("id"), obj.getString("providerId"),
            CareCategory.valueOf(obj.getString("category")), obj.getString("date"),
            obj.getString("startsAt"), obj.getString("endsAt"),
            obj.optString("details", ""), obj.getLong("createdAtMillis"),
            obj.optBoolean("cancelled", false)
        )
    }.filter {
        validDate(it.date) && validTime(it.startsAt) && validTime(it.endsAt) &&
            it.startsAt < it.endsAt && it.id.isNotBlank() && it.providerId.isNotBlank() &&
            it.details.length <= 250
    }

    fun saveBookings(bookings: List<DemoBooking>) {
        val json = JSONArray()
        bookings.forEach { b ->
            json.put(JSONObject().put("id", b.id).put("providerId", b.providerId)
                .put("category", b.category.name).put("date", b.date)
                .put("startsAt", b.startsAt).put("endsAt", b.endsAt)
                .put("details", b.details).put("createdAtMillis", b.createdAtMillis)
                .put("cancelled", b.cancelled))
        }
        prefs.edit().putString("bookings", json.toString()).apply()
    }

    fun loadMessages(): List<DemoMessage> = readArray("messages") { obj ->
        DemoMessage(obj.getString("id"), obj.getString("threadId"),
            MessageAuthor.valueOf(obj.getString("author")), obj.getString("content"),
            obj.getLong("createdAtMillis"))
    }.filter { it.threadId.isNotBlank() && it.content.isNotBlank() }

    fun saveMessages(messages: List<DemoMessage>) {
        val json = JSONArray()
        messages.takeLast(500).forEach { m ->
            json.put(JSONObject().put("id", m.id).put("threadId", m.threadId)
                .put("author", m.author.name).put("content", m.content)
                .put("createdAtMillis", m.createdAtMillis))
        }
        prefs.edit().putString("messages", json.toString()).apply()
    }

    private fun <T> readArray(key: String, parse: (JSONObject) -> T): List<T> {
        val json = runCatching { JSONArray(prefs.getString(key, "[]") ?: "[]") }.getOrNull()
            ?: return emptyList()
        return (0 until json.length()).mapNotNull { i ->
            runCatching { parse(json.getJSONObject(i)) }.getOrNull()
        }
    }
}
