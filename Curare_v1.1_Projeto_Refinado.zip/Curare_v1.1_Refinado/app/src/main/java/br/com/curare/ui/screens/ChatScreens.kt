package br.com.curare.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.curare.data.*
import br.com.curare.ui.components.*
import br.com.curare.ui.theme.*

@Composable
fun HelpHomeScreen(messages: List<DemoMessage>, reports: List<IncidentReport>,
                   providers: List<DemoProvider>, onCuraAI: () -> Unit,
                   onOpenProviderChat: (String) -> Unit, onReport: () -> Unit) {
    val activeProviderIds = messages.asSequence().map { it.threadId }
        .filter { it.startsWith("provider:") }.map { it.removePrefix("provider:") }.distinct().toList()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Conversas e ajuda", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Canais de demonstração para explorar o funcionamento da plataforma.", fontSize = 13.sp, color = Grey)
        SectionCard {
            SectionHeading("CuraAI • Atendimento simulado")
            Text("Assistente com respostas automáticas locais. Ajuda a navegar por agenda, pedidos e ocorrências.", color = Ink)
            CurareButton("Conversar com CuraAI", Modifier.fillMaxWidth(), onClick = onCuraAI)
        }
        SectionCard {
            SectionHeading("Reclamações e denúncias", "Apenas exemplos locais")
            Text("${reports.count { it.serviceId.startsWith("support:") }} ocorrência(s) registradas pelo suporte.",
                color = Grey, fontSize = 13.sp)
            OutlinedButton(onClick = onReport, modifier = Modifier.fillMaxWidth()) {
                Text("Abrir formulário de ocorrência")
            }
        }
        SectionCard {
            SectionHeading("Conversas com prestadores", "Nenhum participante real recebe as mensagens")
            if (activeProviderIds.isEmpty()) {
                Text("Você ainda não iniciou nenhuma conversa. Encontre alguém na aba Serviços.",
                    color = Grey, fontSize = 14.sp)
            } else {
                activeProviderIds.forEach { id ->
                    val provider = providers.firstOrNull { it.id == id }
                    if (provider != null) {
                        OutlinedButton(onClick = { onOpenProviderChat(id) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Chat com ${provider.name} (demo)")
                        }
                    }
                }
            }
        }
        Text("Este protótipo não possui atendimento humano, canais de denúncia oficiais ou IA conectada à internet.",
            color = Grey, fontSize = 12.sp)
    }
}

@Composable
fun DemoChatScreen(
    threadId: String,
    title: String,
    isSupport: Boolean,
    messages: List<DemoMessage>,
    onSend: (String) -> Unit,
    onSimulateReply: () -> Unit,
    onReport: () -> Unit,
    onBack: () -> Unit
) {
    var draft by rememberSaveable(threadId) { mutableStateOf("") }
    val threadMessages = messages.filter { it.threadId == threadId }.sortedBy { it.createdAtMillis }
    val listState = rememberLazyListState()
    LaunchedEffect(threadId, threadMessages.size) {
        if (threadMessages.isNotEmpty()) listState.animateScrollToItem(threadMessages.size)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().background(MintWhite).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Voltar") }
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                Text(if (isSupport) "Assistente por regras • sem internet" else "Conversa apenas neste aparelho",
                    fontSize = 11.sp, color = Grey)
            }
        }
        HorizontalDivider(color = Aqua.copy(alpha = .6f))
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 15.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(if (isSupport) {
                    "Olá! Sou a CuraAI de demonstração. Respondo a perguntas frequentes, mas não sou atendimento humano e não registro denúncias sozinho."
                } else {
                    "Chat demonstrativo. Mensagens digitadas aqui ficam no aparelho e NÃO chegam ao prestador fictício. Para combinar outro horário, escreva uma proposta de exemplo."
                },
                    modifier = Modifier.fillMaxWidth().background(Cloud, RoundedCornerShape(19.dp)).padding(14.dp),
                    color = Ink, fontSize = 14.sp)
            }
            items(threadMessages, key = { it.id }) { message ->
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.author == MessageAuthor.USER) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 310.dp)
                        .background(if (message.author == MessageAuthor.USER) ColorChatUser else Cloud,
                            RoundedCornerShape(18.dp))
                        .padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(message.content, color = Ink, fontSize = 14.sp)
                        Text(when (message.author) {
                            MessageAuthor.USER -> "Você • salvo localmente"
                            MessageAuthor.SIMULATION -> "CuraAI • resposta simulada"
                            MessageAuthor.PROVIDER_SIMULATION -> "Prestador • resposta simulada"
                        },
                            color = Grey, fontSize = 10.sp)
                    }
                }
            }
        }
        if (isSupport) {
            TextButton(onClick = onReport, modifier = Modifier.fillMaxWidth()) {
                Text("Registrar ocorrência fictícia")
            }
        } else {
            TextButton(onClick = onSimulateReply, modifier = Modifier.fillMaxWidth()) {
                Text("Simular uma resposta do prestador")
            }
        }
        Row(Modifier.fillMaxWidth().background(MintWhite).navigationBarsPadding().padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(value = draft, onValueChange = { draft = it.take(500) },
                modifier = Modifier.weight(1f), maxLines = 4,
                placeholder = { Text("Digite uma mensagem de exemplo...") },
                shape = RoundedCornerShape(18.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (draft.isNotBlank()) { onSend(draft.trim()); draft = "" }
                }))
            Button(onClick = { onSend(draft.trim()); draft = "" }, enabled = draft.isNotBlank(),
                modifier = Modifier.heightIn(min = 55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AquaStrong, contentColor = Ink)) {
                Text("Enviar")
            }
        }
    }
}

@Composable
fun SupportReportScreen(reports: List<IncidentReport>, providers: List<DemoProvider>,
                        onSave: (IncidentReport) -> Unit, onBack: () -> Unit) {
    val types = listOf("Conduta inadequada", "Atraso ou ausência", "Cobrança indevida", "Outro")
    var type by rememberSaveable { mutableStateOf(types.first()) }
    var providerId by rememberSaveable { mutableStateOf("none") }
    var description by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf(false) }
    var typeMenu by remember { mutableStateOf(false) }
    var providerMenu by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Reclamações e denúncias", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        SectionCard {
            Text("Este é um formulário de DEMONSTRAÇÃO. Não envia, investiga ou resolve denúncias reais. Não descreva eventos verdadeiros nem forneça dados pessoais.",
                color = Grey, fontSize = 13.sp)
            Text("Prestador de exemplo (opcional)", color = Ink, fontWeight = FontWeight.Medium)
            Box {
                OutlinedButton(onClick = { providerMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(providers.firstOrNull { it.id == providerId }?.name ?: "Nenhum / geral")
                }
                DropdownMenu(expanded = providerMenu, onDismissRequest = { providerMenu = false }) {
                    DropdownMenuItem(text = { Text("Nenhum / geral") }, onClick = {
                        providerId = "none"; providerMenu = false
                    })
                    providers.forEach { provider ->
                        DropdownMenuItem(text = { Text(provider.name) }, onClick = {
                            providerId = provider.id; providerMenu = false
                        })
                    }
                }
            }
            Text("Motivo", color = Ink, fontWeight = FontWeight.Medium)
            Box {
                OutlinedButton(onClick = { typeMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(type) }
                DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                    types.forEach { choice ->
                        DropdownMenuItem(text = { Text(choice) }, onClick = { type = choice; typeMenu = false })
                    }
                }
            }
            OutlinedTextField(value = description, onValueChange = { description = it.take(500) },
                modifier = Modifier.fillMaxWidth(), label = { Text("Descreva um caso inventado") },
                minLines = 3, maxLines = 6, isError = error && description.trim().length < 10,
                supportingText = { Text("${description.length}/500 • mínimo 10 caracteres") })
            if (error && description.trim().length < 10) {
                Text("Descreva ao menos 10 caracteres fictícios.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
            CurareButton("Salvar ocorrência no dispositivo", Modifier.fillMaxWidth()) {
                error = true
                if (description.trim().length >= 10) {
                    onSave(IncidentReport(java.util.UUID.randomUUID().toString(),
                        "support:$providerId", type, description.trim(), System.currentTimeMillis()))
                    saved = true
                    description = ""
                    error = false
                }
            }
        }
        SectionCard {
            SectionHeading("Ocorrências locais", "Nenhum registro é encaminhado")
            val supportReports = reports.filter { it.serviceId.startsWith("support:") }
            if (supportReports.isEmpty()) Text("Nenhuma ocorrência de exemplo registrada.", color = Grey)
            supportReports.reversed().forEach { report ->
                Text("• ${report.type} • ${providers.firstOrNull { it.id == report.serviceId.removePrefix("support:") }?.name ?: "Geral"}",
                    color = Ink, fontSize = 13.sp)
                Text(report.description, color = Grey, fontSize = 12.sp)
                HorizontalDivider(color = Aqua.copy(alpha = .5f))
            }
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
    }
    if (saved) AlertDialog(onDismissRequest = { saved = false },
        title = { Text("Exemplo armazenado") },
        text = { Text("A ocorrência foi salva somente no aparelho. Não foi enviada ao suporte ou às autoridades.") },
        confirmButton = { TextButton(onClick = { saved = false }) { Text("Entendi") } })
}

private val ColorChatUser = androidx.compose.ui.graphics.Color(0xFFDCE5EA)
