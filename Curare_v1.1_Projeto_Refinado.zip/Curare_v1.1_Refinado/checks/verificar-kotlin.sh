#!/usr/bin/env bash
# Requer Kotlin CLI. Valida apenas as regras JVM, não compila a interface Android.
set -euo pipefail
cd "$(dirname "$0")/.."
TMP_JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$TMP_JAR"' EXIT
kotlinc app/src/main/java/br/com/curare/data/CareModels.kt \
        app/src/main/java/br/com/curare/data/Profile.kt \
        app/src/main/java/br/com/curare/data/ProfileValidation.kt \
        app/src/main/java/br/com/curare/data/MarketplaceModels.kt \
        checks/VerifyPhase3.kt -include-runtime -d "$TMP_JAR"
java -jar "$TMP_JAR"
