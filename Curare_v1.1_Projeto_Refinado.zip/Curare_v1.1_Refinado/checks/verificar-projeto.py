#!/usr/bin/env python3
"""Verificações estáticas reproduzíveis, não equivalem a compilar APK."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re

root = Path(__file__).resolve().parent.parent
main = root / "app/src/main"
required = [
    "build.gradle.kts", "settings.gradle.kts", "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/br/com/curare/MainActivity.kt",
    "app/src/main/java/br/com/curare/ui/CurareApp.kt",
    "app/src/main/java/br/com/curare/ui/screens/MarketplaceScreens.kt",
    "app/src/main/java/br/com/curare/ui/screens/ChatScreens.kt",
    "app/src/main/java/br/com/curare/data/MarketplaceModels.kt",
    ".github/workflows/gerar-apk.yml",
]
for item in required:
    assert (root / item).is_file(), f"Arquivo ausente: {item}"
print(f"OK: {len(required)} arquivos de projeto indispensáveis")
for path in sorted((main / "res").rglob("*.xml")) + [main / "AndroidManifest.xml"]:
    ET.parse(path)
print("OK: XML de recursos e manifesto bem formados")
manifest = (main / "AndroidManifest.xml").read_text()
assert 'android.permission.INTERNET' not in manifest
assert 'android:allowBackup="false"' in manifest
assert 'android:exported="true"' in manifest
print("OK: nenhum acesso à internet solicitado; backup de dados desativado")
gradle = (root / "app/build.gradle.kts").read_text()
assert 'applicationId = "br.com.curare"' in gradle
assert 'versionCode = 4' in gradle
assert 'versionName = "1.1.0-academico"' in gradle
assert re.search(r'compileSdk\s*=\s*36', gradle)
assert re.search(r'minSdk\s*=\s*24', gradle)
print("OK: identificador, versão e níveis de SDK consistentes")
app = (main / "java/br/com/curare/ui/CurareApp.kt").read_text()
for screen in ["WELCOME", "REGISTER", "PROFILE", "HISTORY", "SERVICES", "BOOKING", "MY_BOOKINGS", "DIRECT_CHAT", "SUPPORT_CHAT", "SUPPORT_REPORT"]:
    assert screen in app, f"Tela ausente: {screen}"
print("OK: 10 rotas essenciais presentes no código-fonte")
print("OBS: validação estática; compilação Android e teste no aparelho não executados.")
