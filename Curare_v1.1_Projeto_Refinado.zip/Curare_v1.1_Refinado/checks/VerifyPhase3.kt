import br.com.curare.data.*
import java.util.Calendar

fun main() {
    var total = 0
    fun verify(condition: Boolean) {
        check(condition) { "Falha na verificação ${total + 1}" }
        total++
    }
    val providers = sampleProviders()
    verify(providers.size == 6)
    verify(providers.map { it.id }.distinct().size == 6)
    verify(searchProviders(providers, "animais", CareCategory.ANIMAIS, true).size == 3)
    verify(searchProviders(providers, "", null, true).first().id == "gomes")
    verify(searchProviders(providers, "", null, true, ProviderOrder.MORE_SLOTS).first().slots.size == 3)
    verify(searchProviders(providers, "InEXisTEnTE", null, false).isEmpty())
    verify(dayForDate("29/10/2026") == WeekDay.THURSDAY)
    verify(dayForDate("02/11/2026") == WeekDay.MONDAY)
    verify(dayForDate("31/02/2026") == null)
    val now = Calendar.getInstance().apply { set(2026, 9, 29, 9, 0, 0); set(Calendar.MILLISECOND, 0) }
    val gomes = providers.first { it.id == "gomes" }
    verify(canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", emptyList(), now))
    verify(!canRequestBooking(gomes, "02/11/2026", "11:00", "16:00", emptyList(), now))
    verify(!canRequestBooking(gomes, "28/10/2026", "12:00", "16:00", emptyList(), now))
    verify(!canRequestBooking(gomes, "31/10/2026", "12:00", "16:00", emptyList(), now))
    val requested = DemoBooking("1", "gomes", CareCategory.IDOSOS, "02/11/2026", "12:00", "16:00", "", 0)
    verify(!canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", listOf(requested), now))
    verify(canRequestBooking(gomes, "02/11/2026", "12:00", "16:00", listOf(requested.copy(cancelled = true)), now))
    verify(upcomingProviderDates(gomes, now).contains("02/11/2026"))
    verify(!upcomingProviderDates(gomes, now).contains("31/10/2026"))
    verify(demoSupportReply("Quero denunciar uma conduta").contains("ocorrência fictícia"))
    verify(demoSupportReply("Há uma emergência").contains("socorro"))
    verify(demoSupportReply("Quero agendar um horário").contains("aba Serviços"))
    verify(demoSupportReply("o rapaz foi pontual").contains("atendimento automatizado"))
    verify(threadFor("renata") == "provider:renata")
    val owner = localProvider(Profile("Teste Local", 20, UserRole.PRESTADOR,
        "Cuido de cães e gatos", "Passeios com animais e pets"),
        listOf(AvailabilitySlot(WeekDay.MONDAY, "10:00", "12:00")), emptyList())
    verify(owner.isOwnLocalProfile)
    verify(CareCategory.ANIMAIS in owner.categories)
    verify(owner.rating == 0.0)
    verify(!canRequestBooking(providers.first { it.id == "raquel" }, "04/11/2026", "15:00", "19:00",
        emptyList(), Calendar.getInstance().apply { set(2026, 10, 4, 17, 0, 0) }))
    verify(!canRequestBooking(gomes, "16/11/2026", "12:00", "16:00", emptyList(), now))
    verify(!canRequestBooking(owner, "02/11/2026", "10:00", "12:00", emptyList(), now))
    verify(hasBookableSlot(gomes, emptyList(), now))
    val allTaken = upcomingProviderDates(gomes, now).flatMap { day ->
        gomes.slots.filter { it.day == dayForDate(day) }.map { slot ->
            DemoBooking("$day-${slot.startsAt}", gomes.id, CareCategory.IDOSOS,
                day, slot.startsAt, slot.endsAt, "", 0)
        }
    }
    verify(!hasBookableSlot(gomes, allTaken, now))
    verify(hasBookableSlot(gomes, allTaken.map { it.copy(cancelled = true) }, now))
    verify(!hasBookableSlot(owner, emptyList(), now))
    verify(isValidDisplayName("Renata"))
    verify(!isValidDisplayName(" "))
    verify(isValidAgeField(""))
    verify(!isValidAgeField("121"))
    println("$total verificações Kotlin/JVM passaram: cadastro, busca, agendas, conflitos, datas, chat e suporte.")
}
